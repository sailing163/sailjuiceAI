<?php
/**
 * Plugin Name: Sail Results Parser
 * Description: Paste HTML sailing results (WYSIWYG), fetch TackTracker race/course/marks via API, save imports (update by raceid), show race index + race view, and compute SCT/Derived PY/GL excluding outliers.
 * Version: 1.5.2
 * Author: Simon
 */

if (!defined('ABSPATH')) exit;

define('SRP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('SRP_DB_VERSION', '1.4.1');

require_once SRP_PLUGIN_DIR . 'includes/parser.php';
require_once SRP_PLUGIN_DIR . 'includes/tt-api.php';
require_once SRP_PLUGIN_DIR . 'includes/stats.php';
require_once SRP_PLUGIN_DIR . 'includes/xlsx-reader.php';
require_once SRP_PLUGIN_DIR . 'includes/bootstrap.php';


function srp_db_migrate() {
  global $wpdb;
  $charset = $wpdb->get_charset_collate();
  require_once ABSPATH . 'wp-admin/includes/upgrade.php';

  $table_class_summary = $wpdb->prefix . 'srp_class_stats';
  $table_races = $wpdb->prefix . 'srp_races';
  $table_results = $wpdb->prefix . 'srp_results';
  $table_classes = $wpdb->prefix . 'srp_classes';
  $table_race_class_stats = $wpdb->prefix . 'srp_race_class_stats';

  $sql1 = "CREATE TABLE $table_class_summary (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    class_name VARCHAR(191) NOT NULL,
    class_rya_id VARCHAR(100) NULL,
    derived_py DOUBLE NULL,
    derived_py_rya DOUBLE NULL,
    derived_py_best DOUBLE NULL,
    derived_gl DOUBLE NULL,
    sct_avg_lap_s DOUBLE NULL,
    sample_n INT NULL,
    exclusions_n INT NULL DEFAULT 0,
    races_n INT NULL DEFAULT 0,
    appearances_n INT NULL DEFAULT 0,
    last_py DOUBLE NULL,
    outlier_k DOUBLE NULL,
    updated_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY class_name (class_name),
    KEY class_rya_id (class_rya_id)
  ) $charset;";

  $sql2 = "CREATE TABLE $table_races (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    post_id BIGINT UNSIGNED NOT NULL,
    tt_raceid VARCHAR(100) NULL,
    rya_race_id VARCHAR(100) NULL,
    race_name VARCHAR(255) NULL,
    race_start DATETIME NULL,
    source_type VARCHAR(30) NULL,
    class_rya_id VARCHAR(100) NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY post_id (post_id),
    KEY tt_raceid (tt_raceid),
    KEY rya_race_id (rya_race_id),
    KEY class_rya_id (class_rya_id),
    KEY race_start (race_start)
  ) $charset;";

  $sql3 = "CREATE TABLE $table_results (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    race_db_id BIGINT UNSIGNED NOT NULL,
    post_id BIGINT UNSIGNED NOT NULL,
    race_id VARCHAR(100) NULL,
    race_source_id VARCHAR(100) NULL,
    class_rya_id VARCHAR(100) NULL,
    row_index INT NOT NULL DEFAULT 0,
    rank_num INT NULL,
    sail_number VARCHAR(100) NULL,
    helm_name VARCHAR(191) NULL,
    crew_name VARCHAR(191) NULL,
    class_name VARCHAR(191) NULL,
    configuration VARCHAR(191) NULL,
    py DOUBLE NULL,
    laps DOUBLE NULL,
    elapsed_seconds DOUBLE NULL,
    corr_per_lap DOUBLE NULL,
    source_achieved_py DOUBLE NULL,
    derived_py_all DOUBLE NULL,
    derived_py_best DOUBLE NULL,
    derived_py_rya DOUBLE NULL,
    excluded_manual TINYINT(1) NOT NULL DEFAULT 0,
    excluded_all TINYINT(1) NOT NULL DEFAULT 0,
    excluded_best TINYINT(1) NOT NULL DEFAULT 0,
    excluded_rya TINYINT(1) NOT NULL DEFAULT 0,
    exclusion_reason_all VARCHAR(255) NULL,
    exclusion_reason_best VARCHAR(255) NULL,
    exclusion_reason_rya VARCHAR(255) NULL,
    raw_json LONGTEXT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY race_row (race_db_id, row_index),
    KEY post_id (post_id),
    KEY class_name (class_name),
    KEY class_rya_id (class_rya_id),
    KEY sail_number (sail_number),
    KEY race_id (race_id)
  ) $charset;";

  $sql4 = "CREATE TABLE $table_classes (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    class_name VARCHAR(191) NOT NULL,
    class_rya_id VARCHAR(100) NULL,
    updated_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY class_name (class_name),
    KEY class_rya_id (class_rya_id)
  ) $charset;";

  $sql5 = "CREATE TABLE $table_race_class_stats (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    race_db_id BIGINT UNSIGNED NOT NULL,
    post_id BIGINT UNSIGNED NOT NULL,
    class_name VARCHAR(191) NOT NULL,
    class_rya_id VARCHAR(100) NULL,
    method VARCHAR(20) NOT NULL,
    sct DOUBLE NULL,
    derived_py DOUBLE NULL,
    sample_n INT NULL,
    exclusions_n INT NULL DEFAULT 0,
    debug_json LONGTEXT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY race_class_method (race_db_id, class_name, method),
    KEY post_id (post_id),
    KEY class_name (class_name),
    KEY class_rya_id (class_rya_id),
    KEY method (method)
  ) $charset;";

  dbDelta($sql1);
  dbDelta($sql2);
  dbDelta($sql3);
  dbDelta($sql4);
  dbDelta($sql5);

  update_option('srp_db_version', SRP_DB_VERSION);
}

function srp_db_table($suffix) {
  global $wpdb;
  return $wpdb->prefix . $suffix;
}

function srp_db_first_numeric($row, $keys) {
  foreach ($keys as $k) {
    if (isset($row[$k]) && is_numeric($row[$k])) return floatval($row[$k]);
  }
  return null;
}

function srp_db_first_string($row, $keys) {
  foreach ($keys as $k) {
    if (isset($row[$k]) && trim((string)$row[$k]) !== '') return trim((string)$row[$k]);
  }
  return '';
}

function srp_upsert_class_stats(array $class_stats) {
  global $wpdb;
  $table = srp_db_table('srp_class_stats');
  foreach ($class_stats as $class_name => $stats) {
    $data = [
      'class_name' => $class_name,
      'class_rya_id' => isset($stats['class_rya_id']) ? sanitize_text_field((string)$stats['class_rya_id']) : null,
      'derived_py' => isset($stats['derived_py']) ? floatval($stats['derived_py']) : null,
      'derived_py_rya' => isset($stats['derived_py_rya']) ? floatval($stats['derived_py_rya']) : null,
      'derived_py_best' => isset($stats['derived_py_best']) ? floatval($stats['derived_py_best']) : null,
      'derived_gl' => isset($stats['derived_gl']) ? floatval($stats['derived_gl']) : null,
      'sct_avg_lap_s' => isset($stats['sct']) ? floatval($stats['sct']) : null,
      'sample_n' => isset($stats['n']) ? intval($stats['n']) : null,
      'exclusions_n' => isset($stats['exclusions_n']) ? intval($stats['exclusions_n']) : 0,
      'races_n' => isset($stats['races_n']) ? intval($stats['races_n']) : 0,
      'appearances_n' => isset($stats['appearances_n']) ? intval($stats['appearances_n']) : 0,
      'last_py' => isset($stats['last_py']) ? floatval($stats['last_py']) : null,
      'outlier_k' => isset($stats['k']) ? floatval($stats['k']) : 2.0,
      'updated_at' => current_time('mysql'),
    ];
    $wpdb->replace($table, $data);
  }
}

function srp_db_sync_post_to_tables($post_id) {
  global $wpdb;

  $rows_meta = get_post_meta($post_id, 'srp_parsed_rows', true);
  $rows = is_array($rows_meta) ? $rows_meta : json_decode((string)$rows_meta, true);
  if (!is_array($rows)) $rows = [];

  $raceid = (string)get_post_meta($post_id, 'srp_raceid', true);
  $race_name = (string)get_post_meta($post_id, 'srp_race_name', true);
  $rya_race_id = (string)get_post_meta($post_id, 'srp_rya_race_id', true);
  $source_type = (string)get_post_meta($post_id, 'srp_source', true);
  if ($source_type === '') $source_type = 'html';
  $tt_details_meta = get_post_meta($post_id, 'srp_tt_race_details', true);
  $tt_details = is_array($tt_details_meta) ? $tt_details_meta : json_decode((string)$tt_details_meta, true);
  $race_start = null;
  if (is_array($tt_details)) {
    foreach ($tt_details as $k => $v) {
      $lk = strtolower((string)$k);
      if (strpos($lk, 'start') !== false) { $ts = strtotime((string)$v); if ($ts) { $race_start = gmdate('Y-m-d H:i:s', $ts); break; } }
    }
  }

  $class_rya_id = (string)get_post_meta($post_id, 'srp_class_rya_id', true);

  $races_table = srp_db_table('srp_races');
  $results_table = srp_db_table('srp_results');
  $classes_table = srp_db_table('srp_classes');
  $rcs_table = srp_db_table('srp_race_class_stats');

  $wpdb->replace($races_table, [
    'post_id' => intval($post_id),
    'tt_raceid' => $raceid !== '' ? $raceid : null,
    'rya_race_id' => $rya_race_id !== '' ? $rya_race_id : null,
    'race_name' => $race_name !== '' ? $race_name : null,
    'race_start' => $race_start,
    'source_type' => $source_type,
    'class_rya_id' => $class_rya_id !== '' ? $class_rya_id : null,
    'created_at' => current_time('mysql'),
    'updated_at' => current_time('mysql'),
  ]);
  $race_db_id = intval($wpdb->get_var($wpdb->prepare("SELECT id FROM $races_table WHERE post_id=%d", $post_id)));

  $wpdb->delete($results_table, ['post_id' => intval($post_id)]);
  $wpdb->delete($rcs_table, ['post_id' => intval($post_id)]);

  $class_counts = [];
  $class_exclusions = [];
  $class_last_py = [];

  foreach ($rows as $idx => $row) {
    if (!is_array($row)) continue;
    $class_name = srp_db_first_string($row, ['Class','class','Boat','boatname']);
    $class_row_rya_id = srp_db_first_string($row, ['class_rya_id','Class RYA ID','class rya id']);
    if ($class_rya_id === '' && $class_row_rya_id !== '') $class_rya_id = $class_row_rya_id;
    $rank = srp_db_first_numeric($row, ['Rank','rank','Place','place','Position','position','Pos']);
    $sail_number = srp_db_first_string($row, ['Sail Number','sail_number','Sail No','sailno','sail']);
    $helm_name = srp_db_first_string($row, ['Helm Name','help_name','helm_name','Helm','helm','Name','name']);
    $crew_name = srp_db_first_string($row, ['Crew Name','crew_name','Crew','crew']);
    $configuration = srp_db_first_string($row, ['Config.','configuration','Configuration','Type']);
    $py = srp_db_first_numeric($row, ['PY','py','rating','Rating','GL','gl']);
    $laps = srp_db_first_numeric($row, ['Laps','laps','Lap','lap']);
    if (!$laps || $laps <= 0) $laps = 1;
    $elapsed = srp_db_first_numeric($row, ['Elapsed','elapsed','elapsed_time','Time','time']);
    if ($elapsed === null && function_exists('srp_time_to_seconds')) $elapsed = srp_time_to_seconds(srp_db_first_string($row, ['Elapsed','elapsed','elapsed_time','Time','time']));
    $corr = srp_db_first_numeric($row, ['Corr.','Corr','corr','Corrected','corrected']);
    if ($corr === null && $elapsed !== null && $py !== null && $py > 0) $corr = (1000.0 / $py) * ($elapsed / $laps);

    $source_achieved_py = srp_db_first_numeric($row, ['Achieved PY','achieved py','Achieved','achieved']);
    $derived_all = srp_db_first_numeric($row, ['Derived PY/GL (All)']);
    $derived_best = srp_db_first_numeric($row, ['Derived PY/GL (Best)']);
    $derived_rya = srp_db_first_numeric($row, ['Derived PY/GL (RYA)']);

    $excluded_manual = strtolower(srp_db_first_string($row, ['Excluded manual','Manual Excluded'])) === 'yes' ? 1 : 0;
    $excluded_all = strtolower(srp_db_first_string($row, ['Excluded (All)','Excluded'])) === 'yes' ? 1 : 0;
    $excluded_best = strtolower(srp_db_first_string($row, ['Excluded (Best)'])) === 'yes' ? 1 : 0;
    $excluded_rya = strtolower(srp_db_first_string($row, ['Excluded (RYA)'])) === 'yes' ? 1 : 0;

    if ($class_name !== '') {
      $class_counts[$class_name] = ($class_counts[$class_name] ?? 0) + 1;
      $class_exclusions[$class_name] = ($class_exclusions[$class_name] ?? 0) + ($excluded_all ? 1 : 0);
      if ($py !== null && $py > 0) {
        if (!isset($class_last_py[$class_name])) $class_last_py[$class_name] = [];
        $class_last_py[$class_name][] = $py;
      }
      $wpdb->replace($classes_table, [
        'class_name' => $class_name,
        'class_rya_id' => $class_row_rya_id !== '' ? $class_row_rya_id : ($class_rya_id !== '' ? $class_rya_id : null),
        'updated_at' => current_time('mysql'),
      ]);
    }

    $wpdb->replace($results_table, [
      'race_db_id' => $race_db_id,
      'post_id' => intval($post_id),
      'race_id' => $raceid !== '' ? $raceid : null,
      'race_source_id' => $rya_race_id !== '' ? $rya_race_id : null,
      'class_rya_id' => $class_row_rya_id !== '' ? $class_row_rya_id : ($class_rya_id !== '' ? $class_rya_id : null),
      'row_index' => intval($idx),
      'rank_num' => $rank !== null ? intval($rank) : null,
      'sail_number' => $sail_number !== '' ? $sail_number : null,
      'helm_name' => $helm_name !== '' ? $helm_name : null,
      'crew_name' => $crew_name !== '' ? $crew_name : null,
      'class_name' => $class_name !== '' ? $class_name : null,
      'configuration' => $configuration !== '' ? $configuration : null,
      'py' => $py,
      'laps' => $laps,
      'elapsed_seconds' => $elapsed,
      'corr_per_lap' => $corr,
      'source_achieved_py' => $source_achieved_py,
      'derived_py_all' => $derived_all,
      'derived_py_best' => $derived_best,
      'derived_py_rya' => $derived_rya,
      'excluded_manual' => $excluded_manual,
      'excluded_all' => $excluded_all,
      'excluded_best' => $excluded_best,
      'excluded_rya' => $excluded_rya,
      'exclusion_reason_all' => srp_db_first_string($row, ['Exclusion Reason (All)']),
      'exclusion_reason_best' => srp_db_first_string($row, ['Exclusion Reason (Best)']),
      'exclusion_reason_rya' => srp_db_first_string($row, ['Exclusion Reason (RYA)']),
      'raw_json' => wp_json_encode($row),
      'created_at' => current_time('mysql'),
      'updated_at' => current_time('mysql'),
    ]);
  }

  $class_stats_meta = get_post_meta($post_id, 'srp_class_stats', true);
  $class_stats = is_array($class_stats_meta) ? $class_stats_meta : json_decode((string)$class_stats_meta, true);
  if (!is_array($class_stats)) $class_stats = [];

  $dual_meta = get_post_meta($post_id, 'srp_analysis_dual', true);
  $dual = is_array($dual_meta) ? $dual_meta : json_decode((string)$dual_meta, true);
  $debug_all = isset($dual['all']['debug']) ? $dual['all']['debug'] : [];
  $debug_best = isset($dual['best']['debug']) ? $dual['best']['debug'] : [];
  $debug_rya = isset($dual['rya']['debug']) ? $dual['rya']['debug'] : [];

  foreach ($class_stats as $class_name => $stats) {
    if (!is_array($stats)) continue;
    $class_db_rya_id = isset($stats['class_rya_id']) ? sanitize_text_field((string)$stats['class_rya_id']) : ($class_rya_id !== '' ? $class_rya_id : null);
    $wpdb->replace($rcs_table, [
      'race_db_id' => $race_db_id,
      'post_id' => intval($post_id),
      'class_name' => $class_name,
      'class_rya_id' => $class_db_rya_id,
      'method' => 'all',
      'sct' => isset($stats['sct']) ? floatval($stats['sct']) : null,
      'derived_py' => isset($stats['derived_py']) ? floatval($stats['derived_py']) : null,
      'sample_n' => isset($stats['n']) ? intval($stats['n']) : ($class_counts[$class_name] ?? 0),
      'exclusions_n' => $class_exclusions[$class_name] ?? 0,
      'debug_json' => wp_json_encode($debug_all),
      'created_at' => current_time('mysql'),
      'updated_at' => current_time('mysql'),
    ]);
    $wpdb->replace($rcs_table, [
      'race_db_id' => $race_db_id,
      'post_id' => intval($post_id),
      'class_name' => $class_name,
      'class_rya_id' => $class_db_rya_id,
      'method' => 'best',
      'sct' => isset($stats['sct']) ? floatval($stats['sct']) : null,
      'derived_py' => isset($stats['derived_py_best']) ? floatval($stats['derived_py_best']) : null,
      'sample_n' => isset($stats['n']) ? intval($stats['n']) : ($class_counts[$class_name] ?? 0),
      'exclusions_n' => 0,
      'debug_json' => wp_json_encode($debug_best),
      'created_at' => current_time('mysql'),
      'updated_at' => current_time('mysql'),
    ]);
    $wpdb->replace($rcs_table, [
      'race_db_id' => $race_db_id,
      'post_id' => intval($post_id),
      'class_name' => $class_name,
      'class_rya_id' => $class_db_rya_id,
      'method' => 'rya',
      'sct' => isset($stats['sct']) ? floatval($stats['sct']) : null,
      'derived_py' => isset($stats['derived_py_rya']) ? floatval($stats['derived_py_rya']) : null,
      'sample_n' => isset($stats['n']) ? intval($stats['n']) : ($class_counts[$class_name] ?? 0),
      'exclusions_n' => $class_exclusions[$class_name] ?? 0,
      'debug_json' => wp_json_encode($debug_rya),
      'created_at' => current_time('mysql'),
      'updated_at' => current_time('mysql'),
    ]);
  }

  return $race_db_id;
}

function srp_db_rebuild_class_summary() {
  global $wpdb;
  $summary = srp_db_table('srp_class_stats');
  $results = srp_db_table('srp_results');
  $races = srp_db_table('srp_races');
  $rcs = srp_db_table('srp_race_class_stats');

  $wpdb->query("TRUNCATE TABLE $summary");

  $classes = $wpdb->get_results("SELECT class_name, MAX(class_rya_id) AS class_rya_id FROM $results WHERE class_name IS NOT NULL AND class_name <> '' GROUP BY class_name", ARRAY_A);
  foreach ($classes as $c) {
    $class_name = $c['class_name'];
    $class_rya_id = $c['class_rya_id'];

    $appearances = intval($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $results WHERE class_name=%s", $class_name)));
    $exclusions = intval($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $results WHERE class_name=%s AND excluded_all=1", $class_name)));
    $races_n = intval($wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT race_db_id) FROM $results WHERE class_name=%s", $class_name)));
    $py_all = $wpdb->get_var($wpdb->prepare("SELECT AVG(derived_py) FROM $rcs WHERE class_name=%s AND method='all' AND derived_py IS NOT NULL", $class_name));
    $py_best = $wpdb->get_var($wpdb->prepare("SELECT AVG(derived_py) FROM $rcs WHERE class_name=%s AND method='best' AND derived_py IS NOT NULL", $class_name));
    $py_rya = $wpdb->get_var($wpdb->prepare("SELECT AVG(derived_py) FROM $rcs WHERE class_name=%s AND method='rya' AND derived_py IS NOT NULL", $class_name));
    if ($py_all === null) $py_all = $wpdb->get_var($wpdb->prepare("SELECT AVG(derived_py_all) FROM $results WHERE class_name=%s AND derived_py_all IS NOT NULL", $class_name));
    if ($py_best === null) $py_best = $wpdb->get_var($wpdb->prepare("SELECT AVG(derived_py_best) FROM $results WHERE class_name=%s AND derived_py_best IS NOT NULL", $class_name));
    if ($py_rya === null) $py_rya = $wpdb->get_var($wpdb->prepare("SELECT AVG(derived_py_rya) FROM $results WHERE class_name=%s AND derived_py_rya IS NOT NULL", $class_name));
    $last_py = $wpdb->get_var($wpdb->prepare("SELECT py FROM $results WHERE class_name=%s AND py IS NOT NULL ORDER BY id DESC LIMIT 1", $class_name));
    $sample_n = intval($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $results WHERE class_name=%s", $class_name)));
    $wpdb->replace($summary, [
      'class_name' => $class_name,
      'class_rya_id' => $class_rya_id ?: null,
      'derived_py' => $py_all !== null ? floatval($py_all) : null,
      'derived_py_rya' => $py_rya !== null ? floatval($py_rya) : null,
      'derived_py_best' => $py_best !== null ? floatval($py_best) : null,
      'sample_n' => $sample_n,
      'exclusions_n' => $exclusions,
      'races_n' => $races_n,
      'appearances_n' => $appearances,
      'last_py' => $last_py !== null ? floatval($last_py) : null,
      'updated_at' => current_time('mysql'),
    ]);
  }
}

function srp_db_migrate_existing_posts() {
  $posts = get_posts([
    'post_type' => 'srp_import',
    'post_status' => 'any',
    'numberposts' => -1,
    'fields' => 'ids',
  ]);
  if (is_array($posts)) {
    foreach ($posts as $post_id) {
      if (function_exists('srp_recalculate_post_stats')) srp_recalculate_post_stats($post_id);
      srp_db_sync_post_to_tables($post_id);
    }
  }
  srp_db_rebuild_class_summary();
}
// -----------------------------------------------------------------------------
// RYA Bulk Import
// -----------------------------------------------------------------------------

/**
 * Upload an XLSX export where each row is a result line.
 * Creates one srp_import post per race, fetches TT race/course/marks, and optionally processes.
 */

function srp_rya_bulk_import_page() {
  if (!current_user_can('edit_posts')) return;

  echo '<div class="wrap"><h1>RYA Bulk Import</h1>';
  echo '<p>Upload an XLSX file (first sheet) where each row is a result record. This importer supports <strong>date-only</strong> exports. It will help you match each race group to the correct TackTracker <code>raceid</code> before importing.</p>';

  $user_key = 'srp_rya_pending_' . get_current_user_id();
  $pending = get_transient($user_key);

  // Step 2: confirm mappings
  if (!empty($_POST['srp_rya_confirm_import']) && check_admin_referer('srp_rya_confirm_import')) {
    $pending = get_transient($user_key);
    $created_links = [];
    if (empty($pending) || empty($pending['groups'])) {
      echo '<div class="notice notice-error"><p>No pending import found. Please upload the XLSX again.</p></div>';
    } else {
      $mapping = $_POST['srp_tt_match'] ?? [];
      $process_now = !empty($_POST['srp_rya_process_now']);
      $created = 0;
      $errors = [];

      foreach ($pending['groups'] as $gkey => $g) {
        $tt_raceid = isset($mapping[$gkey]) ? sanitize_text_field((string)$mapping[$gkey]) : '';
        // Allow manual override (useful if TT API list-by-date is incomplete or you already know the raceid).
        $manual = $_POST['srp_tt_manual'][$gkey] ?? '';
        $manual = trim(sanitize_text_field((string)$manual));
        if ($manual !== '') {
          // raceid is numeric in TT; keep digits only.
          $manual_digits = preg_replace('/[^0-9]/', '', $manual);
          if ($manual_digits !== '') $tt_raceid = $manual_digits;
        }
        if ($tt_raceid === '') {
          $errors[] = 'Skipped group ' . esc_html($gkey) . ' (no TT race selected).';
          continue;
        }

        $post_id = wp_insert_post([
          'post_type'   => 'srp_import',
          'post_status' => 'private',
          'post_title'  => 'RYA Import ' . $tt_raceid,
        ]);
        if (is_wp_error($post_id) || !$post_id) {
          $errors[] = 'Failed to create import post for TT race ' . $tt_raceid;
          continue;
        }

        $grows = $g['rows'] ?? [];
        update_post_meta($post_id, 'srp_race_id', (string)$tt_raceid);
        update_post_meta($post_id, 'srp_source', 'rya_xlsx');
        update_post_meta($post_id, 'srp_rya_race_id', (string)($g['rya_race_id'] ?? ''));
        update_post_meta($post_id, 'srp_rya_start_id', (string)($g['rya_start_id'] ?? ''));
        update_post_meta($post_id, 'srp_rya_date', (string)($g['date'] ?? ''));
        update_post_meta($post_id, 'srp_parsed_rows', wp_json_encode($grows));

        // Fetch TT Race/Course/Marks (normal flow)
        $race = srp_tt_fetch_race($tt_raceid);
        if ($race) update_post_meta($post_id, 'srp_tt_race', wp_json_encode($race));
        $course = srp_tt_fetch_course($tt_raceid);
        if ($course) update_post_meta($post_id, 'srp_tt_course', wp_json_encode($course));
        $marks = srp_tt_fetch_marks($tt_raceid);
        if ($marks) update_post_meta($post_id, 'srp_tt_marks', wp_json_encode($marks));

        if ($process_now) {
          $k = floatval(get_option('srp_outlier_k', 2.0));
          $computed = srp_compute_dual($grows, $k);
          update_post_meta($post_id, 'srp_rows_with_stats', wp_json_encode($computed['rows'] ?? $grows));
          update_post_meta($post_id, 'srp_class_stats', wp_json_encode($computed['class_stats'] ?? []));
          update_post_meta($post_id, 'srp_debug', wp_json_encode($computed['debug'] ?? []));
        }

        $created_links[] = ['post_id' => $post_id, 'raceid' => $tt_raceid];
        $created++;
      }

      if (!empty($created_links)) {
      echo '<div class="notice notice-success"><p>Imported ' . count($created_links) . ' race(s).</p></div>';
      echo '<ul style="margin-left:20px;">';
      foreach ($created_links as $cl) {
        $url = admin_url('admin.php?page=srp-race-view&post_id=' . intval($cl['post_id']));
        echo '<li><a href="' . esc_url($url) . '">TT raceid ' . esc_html($cl['raceid']) . ' → import #' . intval($cl['post_id']) . '</a></li>';
      }
      echo '</ul>';
      echo '<p><a class="button button-primary" href="' . esc_url(admin_url('admin.php?page=srp-race-index')) . '">Go to Race Index</a></p>';
    }

    delete_transient($user_key);

      echo '<div class="notice notice-success"><p>Created ' . intval($created) . ' import(s).</p></div>';
      if (!empty($errors)) {
        echo '<div class="notice notice-warning"><p><strong>Notes:</strong></p><ul style="margin-left:1.5em;list-style:disc;">';
        foreach ($errors as $e) echo '<li>' . esc_html($e) . '</li>';
        echo '</ul></div>';
      }
      echo '</div>'; // wrap
      return;
    }
  }

  // Step 1: upload and build pending groups
  if (!empty($_POST['srp_rya_bulk_import']) && check_admin_referer('srp_rya_bulk_import')) {
    if (empty($_FILES['srp_rya_file']) || empty($_FILES['srp_rya_file']['tmp_name'])) {
      echo '<div class="notice notice-error"><p>No file uploaded.</p></div>';
    } else {
      $rows = srp_xlsx_read_rows($_FILES['srp_rya_file']['tmp_name']);
      if (empty($rows)) {
        echo '<div class="notice notice-error"><p>Could not read XLSX (or it contains no rows).</p></div>';
      } else {
        $groups = [];
        foreach ($rows as $r) {
          // RYA identifiers
          $rya_race_id = '';
          foreach (['race_id','raceid','Race ID','RaceID'] as $k) {
            if (!empty($r[$k])) { $rya_race_id = trim((string)$r[$k]); break; }
          }
          $rya_start_id = '';
          foreach (['start_id','Start ID','StartID','startid'] as $k) {
            if (!empty($r[$k])) { $rya_start_id = trim((string)$r[$k]); break; }
          }

          $date = srp_rya_guess_date($r);
          if (!$date) $date = 'unknown';

          $gkey = $date . '|' . ($rya_race_id !== '' ? $rya_race_id : 'race?') . '|' . ($rya_start_id !== '' ? $rya_start_id : 'start?');
          if (!isset($groups[$gkey])) {
            $groups[$gkey] = [
              'date' => $date,
              'rya_race_id' => $rya_race_id,
              'rya_start_id' => $rya_start_id,
              'rows' => [],
            ];
          }
          $groups[$gkey]['rows'][] = $r;
        }

	  	  // Preload TT candidates per date (date-only exports).
	  	  // TackTracker list-by-date expects a UTC datetime; use midday to sit safely inside the date.
	  	  $tt_candidates = [];
	  	  foreach ($groups as $g) {
	  	    if (empty($g['date']) || $g['date'] === 'unknown') continue;
	  	    $ymd = is_string($g['date']) ? $g['date'] : '';
	  	    if (!preg_match('/^\\d{4}-\\d{2}-\\d{2}$/', $ymd)) continue;
	  	    if (!isset($tt_candidates[$ymd])) {
	  	    $tt_candidates[$ymd] = srp_tt_list_races_by_date($ymd);
	  	    }
	  	  }

        $pending = [
          'created_at' => time(),
          'groups' => $groups,
          'tt_candidates' => $tt_candidates,
        ];
        set_transient($user_key, $pending, 60 * 60 * 6); // 6 hours
        echo '<div class="notice notice-info"><p>File parsed. Now match each race group to a TackTracker race.</p></div>';
      }
    }
  }

  // If we have pending groups, show matching UI
  $pending = get_transient($user_key);
  if (!empty($pending) && !empty($pending['groups'])) {
    echo '<h2>Step 2 — Match each group to a TackTracker race</h2>';
    echo '<form method="post">';
    wp_nonce_field('srp_rya_confirm_import');
    echo '<table class="widefat striped" style="max-width: 1100px;">';
    echo '<thead><tr><th>RYA Date</th><th>RYA race_id</th><th>RYA start_id</th><th>Rows</th><th>Match TT race</th></tr></thead><tbody>';

    foreach ($pending['groups'] as $gkey => $g) {
      $date = $g['date'] ?? 'unknown';
      $opts = $pending['tt_candidates'][$date] ?? [];
      $row_is_excluded = false; foreach (['Excluded manual','Excluded (All)','Excluded (Best)','Excluded (RYA)'] as $ek){ if (isset($row[$ek]) && strcasecmp((string)$row[$ek],'Yes')===0){ $row_is_excluded = true; break; } } echo '<tr' . ($row_is_excluded ? ' style="opacity:.55;"' : '') . '>';
      echo '<td>' . esc_html($date) . '</td>';
      echo '<td>' . esc_html($g['rya_race_id'] ?? '') . '</td>';
      echo '<td>' . esc_html($g['rya_start_id'] ?? '') . '</td>';
      echo '<td>' . intval(count($g['rows'] ?? [])) . '</td>';

      echo '<td>';
      echo '<select name="srp_tt_match[' . esc_attr($gkey) . ']" style="min-width: 420px;">';
      echo '<option value="">— Select TT race —</option>';
      foreach ($opts as $r) {
        $rid = $r['raceid'] ?? '';
        $label = $rid;
        $nm = trim((string)($r['name'] ?? ''));
        $st = trim((string)($r['start'] ?? ''));
        if ($nm !== '' || $st !== '') $label .= ' — ' . ($nm !== '' ? $nm : '(no name)') . ($st !== '' ? ' @ ' . $st : '');
        echo '<option value="' . esc_attr($rid) . '">' . esc_html($label) . '</option>';
      }
      echo '</select>';

      if (empty($opts)) {
        echo '<div style="margin-top:6px;color:#b45309">No TT races returned for this date. You can enter a TT <code>raceid</code> manually.</div>';
        if ($dbg) {
          echo '<details style="margin-top:6px;"><summary>Debug TackTracker lookup</summary><pre style="white-space:pre-wrap;">' . esc_html(print_r($dbg, true)) . '</pre></details>';
        }
      }

      echo '<div style="margin-top:6px">'
        . '<label style="display:block;font-size:12px;color:#555">Manual TT raceid (optional)</label>'
        . '<input type="text" name="srp_tt_manual[' . esc_attr($gkey) . ']" value="" placeholder="e.g. 1810098250" style="max-width:220px" />'
        . '</div>';

      echo '<div style="margin-top:6px;color:#666;">(If you have many races on a date, use the TT race start time/name above to pick the right one.)</div>';
      echo '</td>';

      echo '</tr>';
    }

  
  $tt_tpl = get_option('srp_tt_viewer_url_tpl', 'https://tacktracker.com/cloud/races/embedlive/%s?namemode=details&leaderboard=true');
    echo '<tr><th scope="row"><label for="srp_tt_viewer_url_tpl">TackTracker viewer URL</label></th><td>';
  echo '<input type="text" id="srp_tt_viewer_url_tpl" name="srp_tt_viewer_url_tpl" value="' . esc_attr($tt_tpl) . '" class="regular-text" />';
  echo '<p class="description">Used for the TT Viewer popup. Use <code>%s</code> where the raceid should go.</p>';
  echo '</td></tr>';
  echo '<tr><th scope="row"><label for="srp_flickr_api_key">Flickr API key</label></th><td>';
  $fkey = get_option('srp_flickr_api_key', '');
  echo '<input type="text" id="srp_flickr_api_key" name="srp_flickr_api_key" value="' . esc_attr($fkey) . '" class="regular-text" />';
  echo '<p class="description">Used to search Flickr via API for photos matching the raceid (public search). No OAuth required for searching public photos.</p>';
  echo '</td></tr>';
  echo '<tr><th scope="row"><label for="srp_flickr_user_id">Flickr user (optional)</label></th><td>';
  $fuid = get_option('srp_flickr_user_id', '');
  echo '<input type="text" id="srp_flickr_user_id" name="srp_flickr_user_id" value="' . esc_attr($fuid) . '" class="regular-text" />';
  echo '<p class="description">If set, restricts search to this user (e.g. <code>12345678@N00</code>).</p>';
  echo '</td></tr>';

  echo '</tbody></table>';

    echo '<p style="margin-top:12px;"><label><input type="checkbox" name="srp_rya_process_now" value="1" checked> Process races immediately (compute SCT/Derived/Class Stats)</label></p>';
    echo '<p><button class="button button-primary" name="srp_rya_confirm_import" value="1">Create Imports</button> ';
    echo '<a class="button" href="' . esc_url(admin_url('admin.php?page=srp-rya-bulk-import')) . '">Upload a different file</a></p>';
    echo '</form>';

    echo '</div>';
    return;
  }

  // Default: show upload form
  echo '<h2>Step 1 — Upload XLSX</h2>';
  echo '<form method="post" enctype="multipart/form-data">';
  wp_nonce_field('srp_rya_bulk_import');
  echo '<table class="form-table" role="presentation"><tbody>';
  echo '<tr><th scope="row"><label for="srp_rya_file">XLSX file</label></th><td><input type="file" id="srp_rya_file" name="srp_rya_file" accept=".xlsx" required></td></tr>';
  echo '</tbody></table>';
  echo '<p><button class="button button-primary" name="srp_rya_bulk_import" value="1">Parse XLSX</button></p>';
  echo '</form>';

  echo '</div>';
}


function srp_rya_guess_start_datetime(array $row): ?int {
  foreach (['start_time','Start time','Start Time','Start'] as $k) {
    if (!empty($row[$k])) {
      $t = trim((string)$row[$k]);
      $ts = strtotime($t . ' UTC');
      if ($ts) return $ts;
    }
  }
  return null;
}

function srp_rya_guess_date(array $row): ?string {
  // Prefer explicit date columns (often date-only in RYA exports)
  $date = '';
  foreach (['date','Date','race_date','Race Date','RaceDate'] as $k) {
    if (!empty($row[$k])) { $date = trim((string)$row[$k]); break; }
  }

  // Handle Excel serial dates (common in XLSX): days since 1899-12-30
  if ($date !== '' && preg_match('/^\d+(?:\.\d+)?$/', $date)) {
    $n = floatval($date);
    if ($n > 30000 && $n < 60000) {
      $ts = (int)(($n - 25569) * 86400); // Excel -> Unix
      return gmdate('Y-m-d', $ts);
    }
  }

  if ($date !== '') {
    $ts = strtotime($date . ' UTC');
    if ($ts) return gmdate('Y-m-d', $ts);
  }

  // Fall back: try parse start_time and take the date part
  foreach (['start_time','Start time','Start Time','Start'] as $k) {
    if (!empty($row[$k])) {
      $t = trim((string)$row[$k]);
      $ts = strtotime($t . ' UTC');
      if ($ts) return gmdate('Y-m-d', $ts);
    }
  }

  return null;
}


function srp_enqueue_leaflet() {
  wp_register_style('srp-leaflet', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css', [], '1.9.4');
  wp_register_script('srp-leaflet', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js', [], '1.9.4', true);
  wp_enqueue_style('srp-leaflet');
  wp_enqueue_script('srp-leaflet');
}


/**
 * Try to extract a course/lap length from the stored course payload.
 */
function srp_format_course_length($course) {
  if (!is_array($course)) return '';
  $candidates = [
    ['lapLengthMeters','m'],
    ['lapLengthMetres','m'],
    ['lapLength','m'],
    ['lapLength_m','m'],
    ['lapLengthKm','km'],
    ['lapLengthNM','nm'],
    ['courseLengthMeters','m'],
    ['courseLengthMetres','m'],
    ['courseLength','m'],
  ];
  foreach ($candidates as $cand) {
    [$k,$unit] = $cand;
    if (isset($course[$k]) && is_numeric($course[$k])) {
      $v = floatval($course[$k]);
      if ($unit === 'm') return number_format_i18n($v, 1) . ' m';
      if ($unit === 'km') return number_format_i18n($v, 3) . ' km';
      if ($unit === 'nm') return number_format_i18n($v, 3) . ' nm';
      return number_format_i18n($v, 2) . ' ' . $unit;
    }
  }
  // sometimes nested
  foreach (['settings','course','data'] as $nest) {
    if (isset($course[$nest]) && is_array($course[$nest])) {
      $x = srp_format_course_length($course[$nest]);
      if ($x) return $x;
    }
  }
  return '';
}

function srp_haversine_m($lat1,$lon1,$lat2,$lon2){
  $R = 6371000.0;
  $phi1 = deg2rad($lat1); $phi2 = deg2rad($lat2);
  $dphi = deg2rad($lat2-$lat1);
  $dl = deg2rad($lon2-$lon1);
  $a = sin($dphi/2)*sin($dphi/2) + cos($phi1)*cos($phi2)*sin($dl/2)*sin($dl/2);
  $c = 2*atan2(sqrt($a), sqrt(1-$a));
  return $R*$c;
}
function srp_course_length_from_marks($course_string, $marks, $finish_at_start=false) {
  if (!$course_string || !is_array($marks) || empty($marks)) return null;
  $lookup = [];
  foreach ($marks as $name => $loc) {
    if (is_array($loc) && isset($loc['lat']) && isset($loc['long'])) {
      $lookup[strtolower(trim((string)$name))] = ['lat'=>(float)$loc['lat'],'lng'=>(float)$loc['long']];
    }
  }
  if (empty($lookup)) return null;

  $s = preg_replace('/[>,;]/', ' ', (string)$course_string);
  $tokens = preg_split('/\s+/', trim($s));
  $points = [];
  foreach ($tokens as $t) {
    $t = trim($t);
    if ($t === '') continue;
    $t = preg_replace('/[\(\)\[\]\{\}]/', '', $t);
    $key = strtolower($t);
    if (isset($lookup[$key])) $points[] = $lookup[$key];
  }
  if (count($points) < 2) return null;

  $dist = 0.0;
  for ($i=1; $i<count($points); $i++) {
    $dist += srp_haversine_m($points[$i-1]['lat'],$points[$i-1]['lng'],$points[$i]['lat'],$points[$i]['lng']);
  }

  // Always treat course as a loop for lap length: include last->first if it isn't already.
  $last = $points[count($points)-1];
  $first = $points[0];
  if ($last['lat'] !== $first['lat'] || $last['lng'] !== $first['lng']) {
    $dist += srp_haversine_m($last['lat'],$last['lng'],$first['lat'],$first['lng']);
  }

  // If finish_at_start is explicitly set, this is already included above; keep arg for backward compat.
  return $dist;
}

function srp_enqueue_datatables() {
  wp_register_style('srp-dt', 'https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css', [], '1.13.8');
  wp_register_script('srp-dt', 'https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js', ['jquery'], '1.13.8', true);
  // FixedHeader extension (for the imported results table header)
  wp_register_style('srp-dt-fixedheader', 'https://cdn.datatables.net/fixedheader/3.4.0/css/fixedHeader.dataTables.min.css', ['srp-dt'], '3.4.0');
  wp_register_script('srp-dt-fixedheader', 'https://cdn.datatables.net/fixedheader/3.4.0/js/dataTables.fixedHeader.min.js', ['srp-dt'], '3.4.0', true);
  wp_enqueue_style('srp-dt');
  wp_enqueue_style('srp-dt-fixedheader');
  wp_enqueue_script('srp-dt');
  wp_enqueue_script('srp-dt-fixedheader');
}

add_action('admin_init', function () {
  register_setting('srp_settings', 'srp_tt_api_key', ['type' => 'string', 'sanitize_callback' => 'sanitize_text_field']);
  register_setting('srp_settings', 'srp_outlier_k', ['type' => 'number', 'sanitize_callback' => 'floatval', 'default' => 2.0]);
  // Maps are enabled by default; can be disabled if performance is an issue.
  register_setting('srp_settings', 'srp_enable_map', ['type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '1']);

  register_setting('srp_settings', 'srp_tt_viewer_url_tpl', ['type' => 'string', 'sanitize_callback' => 'sanitize_text_field']);
  register_setting('srp_settings', 'srp_flickr_api_key', ['type' => 'string', 'sanitize_callback' => 'sanitize_text_field']);
  register_setting('srp_settings', 'srp_flickr_user_id', ['type' => 'string', 'sanitize_callback' => 'sanitize_text_field']);
});


/**
 * Admin modal + helpers
 */
function srp_tt_viewer_url($raceid){
  $tpl = get_option('srp_tt_viewer_url_tpl', 'https://tacktracker.com/cloud/races/embedlive/%s?namemode=details&leaderboard=true');
  return sprintf($tpl, rawurlencode((string)$raceid));
}
function srp_flickr_api_key(){
  return (string)get_option('srp_flickr_api_key', '');
}
function srp_flickr_user_id(){
  return (string)get_option('srp_flickr_user_id', '');
}
function srp_flickr_is_enabled(){
  return srp_flickr_api_key() !== '';
}
function srp_weather_icon_html($wind_raw, $dir_raw){
  $wind = trim((string)$wind_raw);
  $dir = trim((string)$dir_raw);
  if($wind==='' && $dir==='') return '';
  // Parse wind number (knots)
  $wind_num = null;
  if(preg_match('/([0-9]+(?:\.[0-9]+)?)/', $wind, $m)) $wind_num = (float)$m[1];
  $label = $wind_num!==null ? (string)round($wind_num) : $wind;
  if($label!=='') $label .= 'kt';
  $deg = is_numeric($dir) ? (float)$dir : null;
  $rot = $deg!==null ? $deg : 0.0;
  // Simple SVG: circle + arrow
  $svg = '<svg class="srp-wind-svg" width="28" height="28" viewBox="0 0 28 28" aria-hidden="true">'
       . '<circle cx="14" cy="14" r="12" fill="none" stroke="currentColor" stroke-width="1"/>'
       . '<g transform="translate(14 14) rotate(' . esc_attr($rot) . ')">'
       . '<path d="M0 -10 L3 -3 L1 -3 L1 10 L-1 10 L-1 -3 L-3 -3 Z" fill="currentColor"/>'
       . '</g></svg>';
  return '<span class="srp-wind" title="' . esc_attr($wind . ' ' . $dir) . '">' . $svg . '<span class="srp-wind-label">' . esc_html($label) . '</span></span>';
}

add_action('admin_enqueue_scripts', function($hook){
  // Only load on our plugin pages
  $page = isset($_GET['page']) ? sanitize_key((string)$_GET['page']) : '';
  if(strpos($page, 'srp-') !== 0) return;

  wp_add_inline_style('wp-admin', '
    .srp-modal-backdrop{position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:100000;display:none;}
    .srp-modal{position:fixed;inset:5% 5%;background:#fff;z-index:100001;display:none;border-radius:6px;overflow:hidden;box-shadow:0 10px 40px rgba(0,0,0,.35);}
    .srp-modal header{display:flex;align-items:center;justify-content:space-between;padding:10px 12px;background:#f6f7f7;border-bottom:1px solid #dcdcde;}
    .srp-modal header h3{margin:0;font-size:14px;}
    .srp-modal .srp-modal-close{background:transparent;border:0;font-size:18px;line-height:1;cursor:pointer;}
    .srp-modal iframe{width:100%;height:100%;border:0;}
    .srp-modal .srp-modal-body{height:calc(100% - 44px);}
    .srp-modal-btn{margin-right:8px;}
    .srp-wind{display:inline-flex;align-items:center;gap:6px;white-space:nowrap;}
    .srp-wind-svg{display:block;}
    .srp-wind-label{font-size:12px;}
  ');

  wp_add_inline_script('jquery-core', '
    (function(){
      function ensureModal(){
        if(document.getElementById("srpModal")) return;
        var bd=document.createElement("div"); bd.id="srpModalBackdrop"; bd.className="srp-modal-backdrop";
        var m=document.createElement("div"); m.id="srpModal"; m.className="srp-modal";
        m.innerHTML = "<header><h3 id=\"srpModalTitle\">Viewer</h3><button type=\"button\" class=\"srp-modal-close\" aria-label=\"Close\">×</button></header><div class=\"srp-modal-body\"><div id=\"srpModalGallery\" style=\"display:none; padding:12px; overflow:auto; height:100%;\"></div><iframe id=\"srpModalFrame\" src=\"about:blank\" loading=\"lazy\"></iframe></div>";
        document.body.appendChild(bd); document.body.appendChild(m);
        function close(){ bd.style.display="none"; m.style.display="none"; document.getElementById("srpModalFrame").style.display="block"; document.getElementById("srpModalFrame").src="about:blank"; var g=document.getElementById("srpModalGallery"); if(g){ g.style.display="none"; g.innerHTML=""; } }
        bd.addEventListener("click", close);
        m.querySelector(".srp-modal-close").addEventListener("click", close);
        window.srpOpenModal=function(url,title){
          ensureModal(); bd.style.display="block"; m.style.display="block";
          document.getElementById("srpModalTitle").textContent=title||"Viewer";
          var frame=document.getElementById("srpModalFrame");
          var gal=document.getElementById("srpModalGallery");
          if(gal){ gal.style.display="none"; gal.innerHTML=""; }
          frame.style.display="block";
          frame.src=url;
        };
        window.srpOpenGallery=function(title, html){
          ensureModal(); bd.style.display="block"; m.style.display="block";
          document.getElementById("srpModalTitle").textContent=title||"Viewer";
          var frame=document.getElementById("srpModalFrame");
          var gal=document.getElementById("srpModalGallery");
          frame.style.display="none"; frame.src="about:blank";
          if(gal){ gal.style.display="block"; gal.innerHTML=html; }
        };
      }
      ensureModal();
      document.addEventListener("click", function(e){
        var a = e.target.closest("[data-srp-modal-url]");
        if(!a) return;
        e.preventDefault();
        var url=a.getAttribute("data-srp-modal-url");
        var title=a.getAttribute("data-srp-modal-title")||"Viewer";
        // Mobile: hide TackTracker leaderboard if present
        try {
          if (window.innerWidth && window.innerWidth < 700 && url && url.indexOf("leaderboard=true") !== -1) {
            url = url.replace("leaderboard=true", "leaderboard=false");
          }
        } catch(e) {}
        if(window.srpOpenModal) window.srpOpenModal(url,title);
      });
      // Flickr API modal (admin AJAX)
      document.addEventListener("click", function(e){
        var b = e.target.closest("[data-srp-flickr-raceid]");
        if(!b) return;
        e.preventDefault();
        var raceid = b.getAttribute("data-srp-flickr-raceid");
        var title = b.getAttribute("data-srp-modal-title") || ("Flickr: " + raceid);
        if(!window.srpOpenGallery) return;
        window.srpOpenGallery(title, "<p>Loading…</p>");
        var fd = new FormData();
        fd.append("action","srp_flickr_search");
        fd.append("raceid", raceid);
        if(postId) fd.append("post_id", postId);
        if(raceStart) fd.append("race_start", raceStart);
        fetch(ajaxurl, {method:"POST", credentials:"same-origin", body: fd})
          .then(r=>r.json())
          .then(function(data){
            if(!data || !data.success){ throw new Error((data && data.data && data.data.message) ? data.data.message : "Search failed"); }
            var photos = data.data.photos || [];
            if(!photos.length){
              window.srpOpenGallery(title, "<p>No Flickr photos found for <code>"+raceid+"</code>.</p>");
              return;
            }
            var html = "<div style=\"display:flex;flex-wrap:wrap;gap:10px;\">";
            photos.forEach(function(p){
              html += "<a href=\""+p.page+"\" target=\"_blank\" style=\"text-decoration:none;\"><img src=\""+p.thumb+"\" alt=\"\" style=\"width:150px;height:150px;object-fit:cover;border:1px solid #ddd;border-radius:4px;\" /></a>";
            });
            html += "</div><p style=\"margin-top:10px;\"><em>Click a photo to open on Flickr.</em></p>";
            window.srpOpenGallery(title, html);
            // Bind thumbnail clicks to open full image in same modal
            setTimeout(function(){
              document.querySelectorAll(".srp-flickr-thumb").forEach(function(a){
                a.addEventListener("click", function(ev){
                  ev.preventDefault();
                  var full = a.getAttribute("data-full") || "";
                  if(!full) return;
                  window.srpOpenGallery(title, "<div style=\"text-align:center\"><img src=\""+full+"\" style=\"max-width:100%;height:auto\"></div>");
                });
              });
            }, 0);

          })
          .catch(function(err){
            window.srpOpenGallery(title, "<p style=\"color:#b32d2e;\">"+(err && err.message ? err.message : "Error")+"</p>");
          });
      });

    })();
  ');
});

// AJAX handlers (admin)

function srp_ajax_flickr_search(){
  if (!current_user_can('edit_posts')) {
    wp_send_json_error(['message' => 'Not allowed'], 403);
  }
  $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
  $raceid = isset($_POST['raceid']) ? sanitize_text_field(wp_unslash($_POST['raceid'])) : '';
  $start_iso = isset($_POST['start']) ? sanitize_text_field(wp_unslash($_POST['start'])) : '';

  $api_key = srp_flickr_api_key();
  if ($api_key === '') wp_send_json_error(['message' => 'Flickr API key not set (Settings)'], 400);

  $user_id = srp_flickr_user_id();
  if ($user_id === '') wp_send_json_error(['message' => 'Flickr user id required for account-only search (Settings)'], 400);

  if ($start_iso === '' && $post_id > 0) {
    $start_iso = (string)get_post_meta($post_id,'srp_race_start',true);
  }
  if (($start_iso === '' || !strtotime($start_iso)) && $post_id > 0 && $raceid !== '') {
    $tt = srp_tt_get_race_details_cached($post_id, $raceid);
    if (is_array($tt)) {
      $start_iso = (string)($tt['startDateTime'] ?? $tt['start'] ?? $start_iso);
    }
  }
  $start_ts = $start_iso ? strtotime($start_iso) : 0;
  if (!$start_ts) {
    wp_send_json_error(['message' => 'Missing/invalid race start time'], 400);
  }

  $query_min = gmdate('Y-m-d H:i:s', $start_ts - 900); // 15 min before start
  $query_max = gmdate('Y-m-d H:i:s', $start_ts + 3600); // 1 hour after start

  $args = [
    'method' => 'flickr.photos.search',
    'api_key' => $api_key,
    'user_id' => $user_id,
    'per_page' => 200,
    'page' => 1,
    'sort' => 'date-taken-asc',
    'safe_search' => 1,
    'content_type' => 1,
    'media' => 'photos',
    'format' => 'json',
    'nojsoncallback' => 1,
    'min_taken_date' => $query_min,
    'max_taken_date' => $query_max,
    'extras' => 'date_taken,owner_name,url_q,url_c,url_l,url_o',
  ];
  if ($raceid !== '') $args['text'] = $raceid;

  $url = add_query_arg($args, 'https://api.flickr.com/services/rest/');
  $resp = wp_remote_get($url, ['timeout' => 20]);
  if (is_wp_error($resp)) wp_send_json_error(['message' => $resp->get_error_message(), 'url'=>$url], 500);
  $code = wp_remote_retrieve_response_code($resp);
  $body = wp_remote_retrieve_body($resp);
  if ($code < 200 || $code >= 300) wp_send_json_error(['message' => 'Flickr HTTP ' . $code, 'url'=>$url], 500);

  $data = json_decode($body, true);
  $list = (is_array($data) && !empty($data['photos']['photo']) && is_array($data['photos']['photo'])) ? $data['photos']['photo'] : [];
  if (empty($list)) wp_send_json_success(['photos' => [], 'url'=>$url]);

  $within_start = $start_ts;
  $within_end = $start_ts + 3600;

  $photos = [];
  foreach ($list as $p) {
    if (empty($p['id'])) continue;
    $id = (string)$p['id'];
    $thumb = $p['url_q'] ?? '';
    $med = $p['url_c'] ?? ($p['url_l'] ?? ($p['url_o'] ?? ''));
    if ($thumb === '' && !empty($p['secret']) && !empty($p['server'])) {
      $thumb = 'https://live.staticflickr.com/' . rawurlencode($p['server']) . '/' . rawurlencode($id) . '_' . rawurlencode($p['secret']) . '_q.jpg';
    }
    $taken = (string)($p['datetaken'] ?? '');
    $taken_ts = $taken ? strtotime($taken.' UTC') : 0;
    $bucket = ($taken_ts && $taken_ts >= $within_start && $taken_ts <= $within_end) ? 0 : 1;
    $photos[] = [
      'id' => $id,
      'thumb' => $thumb,
      'image' => $med !== '' ? $med : $thumb,
      'title' => (string)($p['title'] ?? ''),
      'date_taken' => $taken,
      'bucket' => $bucket,
    ];
  }
  usort($photos, function($a,$b){
    if ($a['bucket'] !== $b['bucket']) return $a['bucket'] <=> $b['bucket'];
    return strcmp((string)$a['date_taken'], (string)$b['date_taken']);
  });

  wp_send_json_success(['photos' => $photos, 'url'=>$url]);
}



function srp_settings_page() {
  if (!current_user_can('manage_options')) return;
  echo '<div class="wrap"><h1>Sail Results Parser Settings</h1><form method="post" action="options.php">';
  settings_fields('srp_settings');
  $api_key = get_option('srp_tt_api_key', '');
  $k = get_option('srp_outlier_k', 2.0);
  $enable_map = (get_option('srp_enable_map', '1') === '1');
  echo '<table class="form-table" role="presentation"><tbody>';
  echo '<tr><th scope="row"><label for="srp_tt_api_key">TackTracker API Key</label></th><td>';
  echo '<input type="text" id="srp_tt_api_key" name="srp_tt_api_key" value="' . esc_attr($api_key) . '" class="regular-text" />';
  echo '<p class="description">Sent as HTTP header <code>X-API-KEY</code> to <code>https://tacktracker.com/api/</code>.</p>';
  echo '</td></tr>';
  echo '<tr><th scope="row"><label for="srp_outlier_k">Outlier removal (std dev multiplier)</label></th><td>';
  echo '<input type="number" step="0.1" min="0" id="srp_outlier_k" name="srp_outlier_k" value="' . esc_attr($k) . '" class="small-text" />';
  echo '<p class="description">Rows outside mean ± (k × std dev) are excluded when computing SCT (per class).</p>';
  echo '</td></tr>';
  echo '<tr><th scope="row">Map rendering</th><td>';
  echo '<label><input type="checkbox" name="srp_enable_map" value="1" ' . checked(true, $enable_map, false) . ' /> Show Leaflet course maps on race view</label>';
  echo '<p class="description">Disable this if the admin race view feels slow. You can still view results and stats.</p>';
  echo '</td></tr>';
  
  $tt_tpl = get_option('srp_tt_viewer_url_tpl', 'https://tacktracker.com/cloud/races/embedlive/%s?namemode=details&leaderboard=true');
  $flickr_key = get_option('srp_flickr_api_key', '');
  $flickr_user = get_option('srp_flickr_user_id', '');
  echo '<tr><th scope="row"><label for="srp_tt_viewer_url_tpl">TackTracker viewer URL template</label></th><td>';
  echo '<input type="text" id="srp_tt_viewer_url_tpl" name="srp_tt_viewer_url_tpl" value="' . esc_attr($tt_tpl) . '" class="large-text" />';
  echo '<p class="description">Use <code>%s</code> as placeholder for <code>raceid</code>. Example: <code>https://tacktracker.com/cloud/races/embedlive/%s?namemode=details&leaderboard=true</code>. On mobile we automatically flip <code>leaderboard=true</code> to <code>false</code>.</p>';
  echo '</td></tr>';

  echo '<tr><th scope="row"><label for="srp_flickr_api_key">Flickr API key</label></th><td>';
  echo '<input type="text" id="srp_flickr_api_key" name="srp_flickr_api_key" value="' . esc_attr($flickr_key) . '" class="regular-text" />';
  echo '<p class="description">Required for the Flickr popup gallery (Flickr API).</p>';
  echo '</td></tr>';

  echo '<tr><th scope="row"><label for="srp_flickr_user_id">Flickr user id</label></th><td>';
  echo '<input type="text" id="srp_flickr_user_id" name="srp_flickr_user_id" value="' . esc_attr($flickr_user) . '" class="regular-text" placeholder="e.g. 12345678@N00" />';
  echo '<p class="description">Account-only search. Get it from your Flickr profile URL or the Flickr API.</p>';
  echo '</td></tr>';

  echo '</tbody></table>';
  submit_button('Save Settings');
  echo '</form></div>';
}

function srp_admin_page() {
  if (!current_user_can('manage_options')) return;
  echo '<div class="wrap"><h1>Sailing Results Import</h1>';
  echo '<p>Save will <strong>update</strong> the existing record if the TT raceid already exists.</p>';
  srp_render_import_ui(['context'=>'admin','show_debug'=>true,'show_map'=>true]);
  echo '</div>';
}

function srp_race_index_page() {
  if (!current_user_can('manage_options')) return;
  $imports = get_posts(['post_type'=>'srp_import','post_status'=>['private'],'numberposts'=>2000,'orderby'=>'modified','order'=>'DESC']);
  echo '<div class="wrap"><h1>Race Index</h1><p>Saved imports list (search + sort). Click a race to open it.</p>';
  echo '<table id="srp_race_index" class="widefat striped"><thead><tr><th>Race ID</th><th>Race Name</th><th>Start</th><th>Updated</th><th>Has Course</th><th>Has Marks</th><th>Rows</th><th>Weather</th><th>Actions</th></tr></thead><tbody>';
  foreach($imports as $p){
    $raceid=get_post_meta($p->ID,'srp_raceid',true);
    $racename=get_post_meta($p->ID,'srp_race_name',true);
    $race_details=json_decode((string)get_post_meta($p->ID,'srp_tt_race_details',true),true);
    $start=(is_array($race_details)&&!empty($race_details['startDateTime']))?$race_details['startDateTime']:'';
    $course=get_post_meta($p->ID,'srp_tt_course',true);
    $marks=get_post_meta($p->ID,'srp_tt_marks',true);
    $rows=json_decode((string)get_post_meta($p->ID,'srp_parsed_rows',true),true);
    $rows_n=is_array($rows)?count($rows):0;
    $has_course=($course&&$course!=='null')?'Yes':'No';
    $has_marks=($marks&&$marks!=='null')?'Yes':'No';
    $view=admin_url('admin.php?page=srp-race-view&post_id='.intval($p->ID));
    $wind=get_post_meta($p->ID,'srp_weather_wind',true);
    $dir=get_post_meta($p->ID,'srp_weather_dir',true);
    $weather=srp_weather_icon_html($wind,$dir);
    $tt=srp_tt_viewer_url($raceid);
    echo '<tr>'
      . '<td><a href="'.esc_url($view).'">'.esc_html($raceid).'</a></td>'
      . '<td>'.esc_html($racename).'</td>'
      . '<td>'.esc_html($start).'</td>'
      . '<td>'.esc_html(get_the_modified_date('Y-m-d H:i',$p)).'</td>'
      . '<td>'.esc_html($has_course).'</td>'
      . '<td>'.esc_html($has_marks).'</td>'
      . '<td>'.esc_html($rows_n).'</td>'
      . '<td>'.$weather.'</td>'
      . '<td>'
        . '<a class="button button-small" href="'.esc_url($view).'">View</a> '
        . '<a class="button button-small" href="#" data-srp-modal-url="'.esc_url($tt).'" data-srp-modal-title="TackTracker Viewer">TT</a> '
        . '<a class="button button-small" href="#" data-srp-flickr-raceid="'.esc_attr($raceid).'" data-srp-post-id="'.esc_attr($p->ID).'" data-srp-race-start="'.esc_attr($start).'" data-srp-modal-title="Flickr">Flickr</a>'
      . '</td>'
    . '</tr>';

  }
  echo '</tbody></table><script>jQuery(function($){ if($.fn.DataTable) $("#srp_race_index").DataTable({pageLength:100,order:[[2,"desc"]],fixedHeader:true});});</script></div>';
}









function srp_class_stats_page() {
  if (!current_user_can('manage_options')) return;
  global $wpdb;

  $filter_class = isset($_GET['srp_class']) ? sanitize_text_field((string)$_GET['srp_class']) : '';
  $start_date = isset($_GET['srp_start']) ? sanitize_text_field((string)$_GET['srp_start']) : '';
  $end_date   = isset($_GET['srp_end']) ? sanitize_text_field((string)$_GET['srp_end']) : '';

  $races_table = srp_db_table('srp_races');
  $results_table = srp_db_table('srp_results');

  $where = ["res.class_name IS NOT NULL", "res.class_name <> ''"];
  $params = [];
  if ($filter_class !== '') { $where[] = "res.class_name = %s"; $params[] = $filter_class; }
  if ($start_date !== '') { $where[] = "rr.race_start >= %s"; $params[] = $start_date . ' 00:00:00'; }
  if ($end_date !== '') { $where[] = "rr.race_start <= %s"; $params[] = $end_date . ' 23:59:59'; }
  $where_sql = implode(' AND ', $where);

  $class_options_sql = "SELECT DISTINCT res.class_name
    FROM $results_table res
    INNER JOIN $races_table rr ON rr.id = res.race_db_id
    WHERE res.class_name IS NOT NULL AND res.class_name <> ''
    ORDER BY res.class_name ASC";
  $class_options = $wpdb->get_col($class_options_sql);
  if (!is_array($class_options)) $class_options = [];

  $classes_sql = "SELECT DISTINCT res.class_name
    FROM $results_table res
    INNER JOIN $races_table rr ON rr.id = res.race_db_id
    WHERE $where_sql
    ORDER BY res.class_name ASC";
  if (!empty($params)) $classes_sql = $wpdb->prepare($classes_sql, ...$params);
  $class_names = $wpdb->get_col($classes_sql);
  if (!is_array($class_names)) $class_names = [];

  echo '<div class="wrap"><h1>Class Report</h1>';
  echo '<form method="get" style="margin:12px 0 18px 0;">';
  echo '<input type="hidden" name="page" value="srp-class-stats" />';
  echo '<div style="display:flex;gap:16px;align-items:flex-end;flex-wrap:wrap;">';

  echo '<div><label><strong>Class</strong><br/>';
  echo '<select name="srp_class" style="min-width:220px;">';
  echo '<option value="">- Any -</option>';
  foreach ($class_options as $c) {
    $sel = ($filter_class === $c) ? ' selected' : '';
    echo '<option value="' . esc_attr($c) . '"' . $sel . '>' . esc_html($c) . '</option>';
  }
  echo '</select></label></div>';

  echo '<div><label><strong>Start Date</strong><br/>';
  echo '<input type="date" name="srp_start" value="' . esc_attr($start_date) . '" />';
  echo '</label></div>';

  echo '<div><label><strong>End Date</strong><br/>';
  echo '<input type="date" name="srp_end" value="' . esc_attr($end_date) . '" />';
  echo '</label></div>';

  echo '<div><button class="button button-primary" type="submit">Apply</button></div>';
  echo '</div></form>';

  echo '<table id="srp_class_stats" class="widefat striped">';
  echo '<thead><tr>';
  echo '<th>Class</th><th>RYA Class ID</th><th>Races</th><th>Appearances</th><th>Exclusions</th><th>PY (All/SD)</th><th>PY (RYA 66%)</th><th>PY (Best)</th><th>Last PY</th><th>Actions</th>';
  echo '</tr></thead><tbody>';

  foreach ($class_names as $class_name) {
    $metrics_where = ["res.class_name = %s"];
    $metrics_params = [$class_name];
    if ($start_date !== '') { $metrics_where[] = "rr.race_start >= %s"; $metrics_params[] = $start_date . ' 00:00:00'; }
    if ($end_date !== '') { $metrics_where[] = "rr.race_start <= %s"; $metrics_params[] = $end_date . ' 23:59:59'; }
    $mw = implode(' AND ', $metrics_where);

    $rya_id_sql = "SELECT MAX(res.class_rya_id) FROM $results_table res INNER JOIN $races_table rr ON rr.id=res.race_db_id WHERE $mw";
    $rya_id = $wpdb->get_var($wpdb->prepare($rya_id_sql, ...$metrics_params));

    $races_n_sql = "SELECT COUNT(DISTINCT res.race_db_id) FROM $results_table res INNER JOIN $races_table rr ON rr.id=res.race_db_id WHERE $mw";
    $races_n = intval($wpdb->get_var($wpdb->prepare($races_n_sql, ...$metrics_params)));

    $appear_sql = "SELECT COUNT(*) FROM $results_table res INNER JOIN $races_table rr ON rr.id=res.race_db_id WHERE $mw";
    $appearances = intval($wpdb->get_var($wpdb->prepare($appear_sql, ...$metrics_params)));

    $excl_sql = "SELECT COUNT(*) FROM $results_table res INNER JOIN $races_table rr ON rr.id=res.race_db_id
                 WHERE $mw AND (res.excluded_manual=1 OR res.excluded_all=1 OR res.excluded_best=1 OR res.excluded_rya=1)";
    $exclusions = intval($wpdb->get_var($wpdb->prepare($excl_sql, ...$metrics_params)));

    $py_all_sql = "SELECT AVG(race_avg) FROM (
                     SELECT res.race_db_id, AVG(res.derived_py_all) AS race_avg
                     FROM $results_table res
                     INNER JOIN $races_table rr ON rr.id=res.race_db_id
                     WHERE $mw AND res.derived_py_all IS NOT NULL AND res.excluded_manual=0 AND res.excluded_all=0
                     GROUP BY res.race_db_id
                   ) t";
    $py_all = $wpdb->get_var($wpdb->prepare($py_all_sql, ...$metrics_params));

    $py_rya_sql = "SELECT AVG(race_avg) FROM (
                     SELECT res.race_db_id, AVG(res.derived_py_rya) AS race_avg
                     FROM $results_table res
                     INNER JOIN $races_table rr ON rr.id=res.race_db_id
                     WHERE $mw AND res.derived_py_rya IS NOT NULL AND res.excluded_manual=0 AND res.excluded_rya=0
                     GROUP BY res.race_db_id
                   ) t";
    $py_rya = $wpdb->get_var($wpdb->prepare($py_rya_sql, ...$metrics_params));

    $py_best_sql = "SELECT AVG(race_avg) FROM (
                      SELECT res.race_db_id, AVG(res.derived_py_best) AS race_avg
                      FROM $results_table res
                      INNER JOIN $races_table rr ON rr.id=res.race_db_id
                      WHERE $mw AND res.derived_py_best IS NOT NULL AND res.excluded_manual=0 AND res.excluded_best=0
                      GROUP BY res.race_db_id
                    ) t";
    $py_best = $wpdb->get_var($wpdb->prepare($py_best_sql, ...$metrics_params));

    $last_py_sql = "SELECT AVG(py) FROM (
                      SELECT res.race_db_id, AVG(res.py) AS py
                      FROM $results_table res
                      INNER JOIN $races_table rr ON rr.id=res.race_db_id
                      WHERE $mw AND res.py IS NOT NULL
                      GROUP BY res.race_db_id
                      ORDER BY MAX(rr.race_start) DESC, res.race_db_id DESC
                      LIMIT 1
                    ) t";
    $last_py = $wpdb->get_var($wpdb->prepare($last_py_sql, ...$metrics_params));

    $graph_url = admin_url("admin.php?page=srp-class-graph&class=" . urlencode((string)$class_name));
    $races_url = admin_url("admin.php?page=srp-class-races&class=" . urlencode((string)$class_name));
    if ($start_date !== '') { $graph_url = add_query_arg(['srp_start' => $start_date], $graph_url); $races_url = add_query_arg(['srp_start' => $start_date], $races_url); }
    if ($end_date !== '') { $graph_url = add_query_arg(['srp_end' => $end_date], $graph_url); $races_url = add_query_arg(['srp_end' => $end_date], $races_url); }

    echo '<tr>';
    echo '<td>' . esc_html((string)$class_name) . '</td>';
    echo '<td>' . esc_html((string)($rya_id ?? '')) . '</td>';
    echo '<td>' . esc_html($races_n) . '</td>';
    echo '<td>' . esc_html($appearances) . '</td>';
    echo '<td>' . esc_html($exclusions) . '</td>';
    echo '<td><strong>' . esc_html($py_all !== null ? (int)round((float)$py_all) : '') . '</strong></td>';
    echo '<td>' . esc_html($py_rya !== null ? (int)round((float)$py_rya) : '') . '</td>';
    echo '<td>' . esc_html($py_best !== null ? (int)round((float)$py_best) : '') . '</td>';
    echo '<td>' . esc_html($last_py !== null ? (int)round((float)$last_py) : '') . '</td>';
    echo '<td><a href="' . esc_url($graph_url) . '">Graph</a> | <a href="' . esc_url($races_url) . '">Races</a></td>';
    echo '</tr>';
  }

  echo '</tbody></table>';
  echo "<script>jQuery(function($){ if($.fn.DataTable){ $('#srp_class_stats').DataTable({paging:false, pageLength:1000, order:[[3,'desc']]}); } });</script>";
  echo '</div>';
}

function srp_race_view_page() {
  $class_stats = [];
  $calc_debug = null;
  if (!current_user_can('manage_options')) return;
  $post_id=isset($_GET['post_id'])?intval($_GET['post_id']):0;
  if(!$post_id||get_post_type($post_id)!=='srp_import'){ echo '<div class="wrap"><h1>Race View</h1><p><em>Invalid race.</em></p></div>'; return; }
  echo '<div style="margin:10px 0 14px 0;">';
  echo '<form method="post" style="display:inline-block;margin-right:8px;">';
  echo '<input type="hidden" name="srp_action" value="srp_reload_html">';
  wp_nonce_field('srp_reload_html_' . $post_id, 'srp_reload_nonce');
  echo '<button type="submit" class="button">Reload stored HTML</button>';
  echo '</form>';
  echo '</div>';

  // Analysis method toggle (all|best)
  $method = isset($_GET['method']) ? sanitize_key($_GET['method']) : 'all';
  if (!in_array($method, ['all','best'], true)) $method = 'all';

  // Reload stored raw HTML and reparse this race
  if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['srp_action']) && $_POST['srp_action'] === 'srp_reload_html') {
    if (!isset($_POST['srp_reload_nonce']) || !wp_verify_nonce($_POST['srp_reload_nonce'], 'srp_reload_html_' . $post_id)) {
      echo '<div class="notice notice-error"><p>' . esc_html('Security check failed.') . '</p></div>';
    } else {
      $raw_html = (string) get_post_meta($post_id, 'srp_raw_html', true);
      if (trim($raw_html) === '') {
        echo '<div class="notice notice-error"><p>' . esc_html('No stored raw HTML found for this race.') . '</p></div>';
      } else {
        $parse_result = srp_parse_results_html($raw_html);
        if (!empty($parse_result['error'])) {
          echo '<div class="notice notice-error"><p>' . esc_html($parse_result['error']) . '</p></div>';
        } else {
          $rows = isset($parse_result['rows']) && is_array($parse_result['rows']) ? $parse_result['rows'] : [];
          // fallback Corr. calc if parser didn't map a corrected column
          if (!empty($rows) && !isset($rows[0]['Corr.'])) {
            foreach ($rows as &$row) {
              $elapsed_raw = $row['Elapsed'] ?? '';
              $elapsed = is_numeric($elapsed_raw) ? floatval($elapsed_raw) : (function_exists('srp_time_to_seconds') ? srp_time_to_seconds($elapsed_raw) : 0);
              $laps = isset($row['Laps']) && is_numeric($row['Laps']) ? floatval($row['Laps']) : 1;
              if ($laps <= 0) $laps = 1;
              $py = isset($row['PY']) && is_numeric($row['PY']) ? floatval($row['PY']) : 1000;
              $row['Corr.'] = ($elapsed > 0 && $py > 0) ? (int) round((1000.0 / $py) * ($elapsed / $laps)) : '';
            }
            unset($row);
          }
          // mark obviously incomplete rows as excluded before recalc
          foreach ($rows as &$r) {
            $elapsed_ok = !empty($r['Elapsed']) && (is_numeric($r['Elapsed']) || (function_exists('srp_time_to_seconds') && srp_time_to_seconds($r['Elapsed']) !== null));
            $corr_ok = !empty($r['Corr.']) && (is_numeric($r['Corr.']) || (function_exists('srp_time_to_seconds') && srp_time_to_seconds($r['Corr.']) !== null));
            $source_ok = !empty($r['Source Achieved PY']) && is_numeric($r['Source Achieved PY']);
            if (!$elapsed_ok && !$corr_ok && !$source_ok) {
              $r['Excluded manual'] = 'Yes';
              if (empty($r['Manual Exclusion Reason'])) $r['Manual Exclusion Reason'] = 'No elapsed/corr';
              $r['Excluded (All)'] = 'Yes';
              $r['Excluded (Best)'] = 'Yes';
              $r['Excluded (RYA)'] = 'Yes';
            }
          }
          unset($r);
          update_post_meta($post_id, 'srp_parsed_rows', wp_json_encode($rows));
          update_post_meta($post_id, 'srp_parse_debug', wp_json_encode($parse_result['debug'] ?? []));
          if (function_exists('srp_recalculate_post_stats')) srp_recalculate_post_stats($post_id);
          if (function_exists('srp_db_rebuild_class_summary')) srp_db_rebuild_class_summary();
          echo '<div class="notice notice-success"><p>' . esc_html('Reloaded stored HTML and rebuilt parsed rows.') . '</p></div>';
        }
      }
    }
  }


  // Save Weather (Wind/Direction/Temperature/Pressure)
  if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['srp_action']) && $_POST['srp_action'] === 'srp_save_weather') {
    if (!isset($_POST['srp_weather_nonce']) || !wp_verify_nonce($_POST['srp_weather_nonce'], 'srp_weather_' . $post_id)) {
      echo '<div class="notice notice-error"><p>' . esc_html('Security check failed.') . '</p></div>';
    } else {
      $wind = isset($_POST['srp_weather_wind']) ? sanitize_text_field(wp_unslash($_POST['srp_weather_wind'])) : '';
      $dir  = isset($_POST['srp_weather_dir']) ? sanitize_text_field(wp_unslash($_POST['srp_weather_dir'])) : '';
      $temp = isset($_POST['srp_weather_temp']) ? sanitize_text_field(wp_unslash($_POST['srp_weather_temp'])) : '';
      $pres = isset($_POST['srp_weather_pressure']) ? sanitize_text_field(wp_unslash($_POST['srp_weather_pressure'])) : '';

      update_post_meta($post_id, 'srp_weather_wind', $wind);
      update_post_meta($post_id, 'srp_weather_dir', $dir);
      update_post_meta($post_id, 'srp_weather_temp', $temp);
      update_post_meta($post_id, 'srp_weather_pressure', $pres);

      echo '<div class="notice notice-success"><p>' . esc_html('Saved weather fields.') . '</p></div>';
    }
  }

  // Recalculate button handler (uses saved rows; updates post meta + class stats table)
  if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['srp_action']) && $_POST['srp_action'] === 'srp_recalc') {
    if (!isset($_POST['srp_nonce']) || !wp_verify_nonce($_POST['srp_nonce'], 'srp_recalc_' . $post_id)) {
      echo '<div class="notice notice-error"><p>' . esc_html('Security check failed.') . '</p></div>';
    } else {
      $method = isset($_GET['method']) ? sanitize_key($_GET['method']) : 'all';
      if (!in_array($method, ['all','best'], true)) $method = 'all';
      $dual = get_post_meta($post_id, 'srp_analysis_dual', true);
      if (is_array($dual) && isset($dual[$method]['rows'])) {
        $saved_rows = $dual[$method]['rows'];
        $calc_debug = $dual[$method]['debug'] ?? null;
        $class_stats = $dual[$method]['class_stats'] ?? [];
      } else {
        $saved_rows = json_decode((string)get_post_meta($post_id, 'srp_parsed_rows', true), true);
                $calc_debug = json_decode((string)get_post_meta($post_id, 'srp_calc_debug', true), true);
      }
      if (!is_array($saved_rows) || empty($saved_rows)) {
        echo '<div class="notice notice-error"><p>' . esc_html('No saved rows to recalculate.') . '</p></div>';
      } else {
        $k = floatval(get_option('srp_outlier_k', 2.0));
        
        $stats_dual = (function_exists('srp_compute_dual_v2') ? srp_compute_dual_v2($saved_rows, $k) : srp_compute_dual($saved_rows, $k));
        update_post_meta($post_id, 'srp_analysis_dual', wp_json_encode($stats_dual));
        $stats_result = isset($stats_dual['all']) ? $stats_dual['all'] : $stats_dual;

        if (!empty($stats_result['rows'])) {
          $merged = srp_merge_dual_rows($stats_dual);
          update_post_meta($post_id, 'srp_parsed_rows', wp_json_encode($merged));
        }
        if (!empty($stats_result['class_stats'])) {
          $merged_class_stats = srp_merge_dual_class_stats($stats_dual);
          srp_upsert_class_stats($merged_class_stats);
          update_post_meta($post_id, 'srp_class_stats', wp_json_encode($merged_class_stats));
        }
        if (!empty($stats_result['debug'])) update_post_meta($post_id, 'srp_stats_debug', wp_json_encode($stats_result['debug']));

        // refresh local vars (so the page shows new results immediately)
        $rows = json_decode((string)get_post_meta($post_id, 'srp_parsed_rows', true), true);
        
        echo '<div class="notice notice-success"><p>' . esc_html('Recalculated SCT / PY / GL from saved results.') . '</p></div>';
      }
    }
  }




  $raceid=get_post_meta($post_id,'srp_raceid',true);
  $racename=get_post_meta($post_id,'srp_race_name',true);
  $race_details=json_decode((string)get_post_meta($post_id,'srp_tt_race_details',true),true);
  $course=json_decode((string)get_post_meta($post_id,'srp_tt_course',true),true);
  $marks=json_decode((string)get_post_meta($post_id,'srp_tt_marks',true),true);
  $rows=json_decode((string)get_post_meta($post_id,'srp_parsed_rows',true),true);

  $weather_wind = get_post_meta($post_id, 'srp_weather_wind', true);
  $weather_dir  = get_post_meta($post_id, 'srp_weather_dir', true);
  $weather_temp = get_post_meta($post_id, 'srp_weather_temp', true);
  $weather_pres = get_post_meta($post_id, 'srp_weather_pressure', true);
  
  echo '<div class="wrap"><h1>Race View</h1><p><a href="'.esc_url(admin_url('admin.php?page=srp-race-index')).'">&larr; Back to Race Index</a></p>';

  echo '<form method="post" style="margin: 10px 0 20px 0;">';
  wp_nonce_field('srp_recalc_' . $post_id, 'srp_nonce');
  echo '<input type="hidden" name="srp_action" value="srp_recalc" />';
  echo '<button type="submit" class="button button-secondary">Recalculate SCT / PY / GL</button>';
  echo '</form>';

  $base = admin_url('admin.php?page=srp-race-view&post_id=' . $post_id);
  $url_all = add_query_arg(['method'=>'all'], $base);
  $url_best = add_query_arg(['method'=>'best'], $base);
  echo '<div style="margin:10px 0 14px 0;">';
  echo '<strong>Analysis method:</strong> ';
  echo '<a class="button ' . ($method==='all'?'button-primary':'') . '" href="' . esc_url($url_all) . '">All boats (exclude outliers)</a> ';
  echo '<a class="button ' . ($method==='best'?'button-primary':'') . '" href="' . esc_url($url_best) . '">Best of each class</a>';
  echo '</div>';


  echo '<h2>'.esc_html($racename?$racename:('TT Race '.$raceid)).'</h2>';
  if(is_array($race_details)){
    $start=$race_details['startDateTime']??'';
    $race_start_iso = $start;
    $event=$race_details['eventType']??'';
    echo '<p><strong>Race ID:</strong> '.esc_html($raceid).'<br/>';
    if($start) echo '<strong>Start:</strong> '.esc_html($start).'<br/>';
    if($event) echo '<strong>Event Type:</strong> '.esc_html($event).'<br/>';
    echo '</p>';

    $tt_url = srp_tt_viewer_url($raceid);
    $flickr_enabled = srp_flickr_is_enabled();
    echo '<p style="margin-top:6px;">'
      . '<a class="button srp-modal-btn" href="#" data-srp-modal-url="' . esc_url($tt_url) . '" data-srp-modal-title="TackTracker Viewer">TT Viewer</a>'
      . ($flickr_enabled ? '<a class="button srp-modal-btn" href="#" data-srp-flickr-raceid="' . esc_attr($raceid) . '" data-srp-modal-title="Flickr">Flickr</a>' : '<span class="button disabled" title="Set Flickr API key in Settings">Flickr</span>')
      . '</p>';

  }

  // Weather block (editable)
  echo '<h2>Weather</h2>';
  echo '<form method="post" style="max-width: 900px; margin: 0 0 20px 0; padding: 12px; border: 1px solid #ccd0d4; border-radius: 6px; background: #fff;">';
  wp_nonce_field('srp_weather_' . $post_id, 'srp_weather_nonce');
  echo '<input type="hidden" name="srp_action" value="srp_save_weather" />';
  echo '<div style="display:flex; gap:12px; flex-wrap:wrap; align-items:flex-end;">';
  echo '<label style="display:block; min-width: 170px;"><strong>Wind</strong><br/><input type="text" name="srp_weather_wind" value="' . esc_attr($weather_wind) . '" placeholder="e.g. 12 kt" class="regular-text" /></label>';
  echo '<label style="display:block; min-width: 170px;"><strong>Direction</strong><br/><input type="text" name="srp_weather_dir" value="' . esc_attr($weather_dir) . '" placeholder="e.g. 240°" class="regular-text" /></label>';
  echo '<label style="display:block; min-width: 170px;"><strong>Temperature</strong><br/><input type="text" name="srp_weather_temp" value="' . esc_attr($weather_temp) . '" placeholder="e.g. 9°C" class="regular-text" /></label>';
  echo '<label style="display:block; min-width: 170px;"><strong>Pressure</strong><br/><input type="text" name="srp_weather_pressure" value="' . esc_attr($weather_pres) . '" placeholder="e.g. 1012 hPa" class="regular-text" /></label>';
  echo '<button type="submit" class="button button-primary" style="height: 30px;">Save Weather</button>';
  echo '</div>';
  echo '</form>';

  $points=[]; $course_string=''; $finish_at_start=null; $hazards=[];
  if(is_array($course)){
    $course_string=isset($course['course'])?(string)$course['course']:'';
    $finish_at_start=isset($course['finishAtStart'])?(bool)$course['finishAtStart']:null;
    $hazards=(!empty($course['hazards'])&&is_array($course['hazards']))?$course['hazards']:[];
  }
  if(is_array($marks)){
    foreach($marks as $name=>$loc){ if(is_array($loc)&&isset($loc['lat'])&&isset($loc['long'])) $points[]=['name'=>(string)$name,'lat'=>(float)$loc['lat'],'lng'=>(float)$loc['long'],'type'=>'mark']; }
  }
  if(!empty($hazards)){
    foreach($hazards as $name=>$loc){ if(is_array($loc)&&isset($loc['lat'])&&isset($loc['long'])) $points[]=['name'=>(string)$name,'lat'=>(float)$loc['lat'],'lng'=>(float)$loc['long'],'type'=>'hazard']; }
  }

  echo '<h2>Course & Map</h2>';
  if($course_string) echo '<p><strong>Course:</strong> <code>'.esc_html($course_string).'</code></p>';
  $course_len = srp_format_course_length($course);
  if ($course_len) echo '<p><strong>Course length:</strong> ' . esc_html($course_len) . '</p>';
  if(!is_null($finish_at_start)) echo '<p><strong>Finish at start:</strong> '.($finish_at_start?'Yes':'No').'</p>';
  // Course length from TT payload if available, else calculate from marks + course string
  $course_len = srp_format_course_length($course);
  if ($course_len) {
    echo '<p><strong>Course length:</strong> ' . esc_html($course_len) . '</p>';
  } else {
    $calc_m = srp_course_length_from_marks($course_string, is_array($marks) ? $marks : [], (bool)$finish_at_start);
    if ($calc_m !== null) {
      $nm = $calc_m / 1852.0;
      echo '<p><strong>Course length (from marks):</strong> ' . esc_html(number_format_i18n($calc_m, 0)) . ' m (' . esc_html(number_format_i18n($nm, 2)) . ' nm)</p>';
    }
  }

  // Map rendering can be turned off in Settings if performance is an issue.
  $enable_map = (get_option('srp_enable_map', '1') === '1');
  if(!empty($points) && $enable_map){
    $map_id='srp_race_view_map';
    echo '<div id="'.esc_attr($map_id).'" style="height:420px; max-width:100%; border:1px solid #ccd0d4; border-radius:6px;"></div>';
    $json_points=wp_json_encode($points);
    
$srp_pts = $json_points;
$srp_el  = json_encode($map_id);
$srp_course = wp_json_encode((string)$course_string);

$srp_js = <<<JS
document.addEventListener("DOMContentLoaded", function() {
  if (typeof L === "undefined") return;
  var pts = $srp_pts;
  var el = document.getElementById($srp_el);
  if (!el) return;

  // Expose for debugging
  window.srpMarkPoints = pts;
  var courseStr = $srp_course;
  window.srpCourseStr = courseStr;

  var map = L.map(el);

  // NOTE: Map rotation disabled (north-up) for performance and to avoid confusing the base map.
  function srpGetLatLng(p){
    if(!p) return null;
    if(Array.isArray(p) && p.length>=2){ return {lat:parseFloat(p[0]), lng:parseFloat(p[1])}; }
    if(typeof p==='object' && p.lat!=null && p.lng!=null){ return {lat:parseFloat(p.lat), lng:parseFloat(p.lng)}; }
    if(typeof p==='object' && p[0]!=null && p[1]!=null){ return {lat:parseFloat(p[0]), lng:parseFloat(p[1])}; }
    return null;
  }

  function srpBearing(a,b){
    a = srpGetLatLng(a); b = srpGetLatLng(b);
    if(!a || !b || isNaN(a.lat) || isNaN(a.lng) || isNaN(b.lat) || isNaN(b.lng)) return 0;
    var toRad = function(x){return x*Math.PI/180;};
    var toDeg = function(x){return x*180/Math.PI;};
    var lat1=toRad(a.lat), lat2=toRad(b.lat);
    var dLon=toRad(b.lng-a.lng);
    var y=Math.sin(dLon)*Math.cos(lat2);
    var x=Math.cos(lat1)*Math.sin(lat2)-Math.sin(lat1)*Math.cos(lat2)*Math.cos(dLon);
    return (toDeg(Math.atan2(y,x))+360)%360;
  }

  
  // (Rotation code removed.)

  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {maxZoom:19, attribution:"&copy; OpenStreetMap contributors"}).addTo(map);

  function norm(s){ return (s||"").toString().trim().toLowerCase(); }
  function extractNum(s){ var mm=(s||"").toString().match(/(\d+)/); return mm ? parseInt(mm[1],10) : null; }

  var markByName = {};
  var markByNum = {};
  var b = [];

  pts.forEach(function(p){
    // circle marker + centered permanent label
    var cm = L.circleMarker([p.lat, p.lng], {radius:8, weight:2, opacity:1, fillOpacity:0.7}).addTo(map);
    cm.bindPopup("<strong>"+p.name+"</strong><br/>"+p.type+"<br/>"+p.lat.toFixed(6)+", "+p.lng.toFixed(6));
    cm.bindTooltip(p.name, {permanent:true, direction:"center", className:"srp-mark-label"});

    b.push([p.lat,p.lng]);
    markByName[norm(p.name)] = [p.lat,p.lng];
    var n = extractNum(p.name);
    if (n !== null && !markByNum[n]) markByNum[n] = [p.lat,p.lng];

    // Capture start/finish buoys/pins if present
    var pn = norm(p.name);
    if (pn.indexOf("startboat") !== -1) window.srpStartBoat = [p.lat,p.lng];
    if (pn.indexOf("startpin")  !== -1) window.srpStartPin  = [p.lat,p.lng];
    if (pn === "start") window.srpStart = [p.lat,p.lng];

    if (pn.indexOf("finishboat") !== -1) window.srpFinishBoat = [p.lat,p.lng];
    if (pn.indexOf("finishpin")  !== -1) window.srpFinishPin  = [p.lat,p.lng];
    if (pn === "finish") window.srpFinish = [p.lat,p.lng];

  });

  window.srpMarkByName = markByName;
  window.srpMarkByNum = markByNum;

  if (b.length === 1) map.setView(b[0], 14);
  else if (b.length > 1) map.fitBounds(b, {padding:[20,20]});

  // Draw start/finish lines (StartBoat--StartPin, FinishBoat--FinishPin) if available
  function mid(a,b){ return [(a[0]+b[0])/2, (a[1]+b[1])/2]; }
  if (window.srpStartBoat && window.srpStartPin) {
    var sl = L.polyline([window.srpStartBoat, window.srpStartPin], {weight:2, opacity:0.9, dashArray:"6,4"}).addTo(map);
    L.circleMarker(mid(window.srpStartBoat, window.srpStartPin), {radius:2, opacity:0, fillOpacity:0}).addTo(map)
      .bindTooltip("Start", {permanent:true, direction:"center", className:"srp-leg-label"});
  }
  if (window.srpFinishBoat && window.srpFinishPin) {
    var fl = L.polyline([window.srpFinishBoat, window.srpFinishPin], {weight:2, opacity:0.9, dashArray:"6,4"}).addTo(map);
    L.circleMarker(mid(window.srpFinishBoat, window.srpFinishPin), {radius:2, opacity:0, fillOpacity:0}).addTo(map)
      .bindTooltip("Finish", {permanent:true, direction:"center", className:"srp-leg-label"});
  }


  // Build course points from tokens
  var tokens = (courseStr||"").replace(/[>,;]/g," ").split(/\\s+/).filter(Boolean);
  var linePts = [];
  tokens.forEach(function(t){
    var key = norm(t);
    if (markByName[key]) { linePts.push(markByName[key]); return; }
    var n = extractNum(key);
    if (n !== null && markByNum[n]) linePts.push(markByNum[n]);
  });

  // Close loop for 4-1 etc.
  if (linePts.length >= 2) {
    var first = linePts[0], last = linePts[linePts.length-1];
    if (first[0] !== last[0] || first[1] !== last[1]) linePts.push(first);
  }

  window.srpCoursePts = linePts;
          window.srpCoursePoints = linePts;

  // Draw line + leg angles (Leg 1 = last->first, i.e. closing leg) as 0° reference
  function haversineM(a,b){
    var R=6371000;
    var lat1=a[0]*Math.PI/180, lat2=b[0]*Math.PI/180;
    var dlat=(b[0]-a[0])*Math.PI/180, dlon=(b[1]-a[1])*Math.PI/180;
    var s=Math.sin(dlat/2)*Math.sin(dlat/2)+Math.cos(lat1)*Math.cos(lat2)*Math.sin(dlon/2)*Math.sin(dlon/2);
    var c=2*Math.atan2(Math.sqrt(s),Math.sqrt(1-s));
    return R*c;
  }

  function bearingDeg(a,b){
    var lat1=a[0]*Math.PI/180, lon1=a[1]*Math.PI/180;
    var lat2=b[0]*Math.PI/180, lon2=b[1]*Math.PI/180;
    var y = Math.sin(lon2-lon1)*Math.cos(lat2);
    var x = Math.cos(lat1)*Math.sin(lat2) - Math.sin(lat1)*Math.cos(lat2)*Math.cos(lon2-lon1);
    var brng = Math.atan2(y,x)*180/Math.PI;
    return (brng+360)%360;
  }
  function relAngle(a, ref){
    var d = (a - ref + 360) % 360;
    if (d > 180) d = d - 360;
    return d;
  }

  if (linePts.length >= 2) {
    var pl = L.polyline(linePts, {weight:3, opacity:0.85}).addTo(map);
    try { map.fitBounds(pl.getBounds().pad(0.2)); } catch(e) {}

    // Compute reference bearing for Leg 1: last->first (closing leg) if we have closure
    var refBearing = bearingDeg(linePts[linePts.length-2], linePts[linePts.length-1]);

    for (var i=1; i<linePts.length; i++){
      var a = linePts[i-1], b2 = linePts[i];
      var mid = [(a[0]+b2[0])/2, (a[1]+b2[1])/2];
      var br = bearingDeg(a,b2);
      var rel = relAngle(br, refBearing);
      var legNum = i; // Leg 1 corresponds to closing leg if closure is last segment
      // If course provided 1..n then closure is last leg; label accordingly:
      // i == linePts.length-1 => closing leg
      var meters = haversineM(a,b2);
      var mtxt = meters >= 1000 ? (meters/1000).toFixed(2)+" km" : Math.round(meters)+" m";
      var label;
      if (i === linePts.length-1) {
        label = "Leg 1 (closing): 0°, " + mtxt;
      } else {
        label = "Leg " + (i+1) + ": " + rel.toFixed(0) + "°, " + mtxt;
      }
      L.circleMarker(mid, {radius:0, opacity:0, fillOpacity:0}).addTo(map)
        .bindTooltip(label, {permanent:true, direction:"center", className:"srp-leg-label"});
    }
  }
});
JS;

echo "<style>
.srp-mark-label{background:transparent;border:0;box-shadow:none;color:#111;font-weight:700;font-size:12px;text-shadow:0 1px 2px rgba(255,255,255,0.9);}
.srp-leg-label{background:rgba(255,255,255,0.85);border:1px solid rgba(0,0,0,0.15);box-shadow:none;color:#111;font-weight:600;font-size:11px;}
</style>";

echo "<script>{$srp_js}</script>";

  } else echo '<p><em>No mark coordinates saved for this race.</em></p>';

  echo '<h2>Derived SCT / PY / GL</h2>';
  if(is_array($class_stats)&&!empty($class_stats)){
    echo '<div class="srp-threshold-box"><strong>Outlier thresholds</strong><div id="srp_thresholds_note"></div></div><table id="srp_race_class_stats" class="widefat striped"><thead><tr><th>Class</th><th>SCT</th><th>PY (All/SD)</th><th>PY (RYA 66%)</th><th>PY (Best)</th><th>Samples</th><th>Low</th><th>High</th></tr></thead><tbody>';
    foreach($class_stats as $cls=>$st){
      $sct=isset($st['sct_best_lap_s'])?round((float)$st['sct_best_lap_s'],2):'';
      $py=isset($st['derived_py'])?(int)round((float)$st['derived_py']):'';
      $py_rya=isset($st['derived_py_rya'])?(int)round((float)$st['derived_py_rya']):'';
      $py_best=isset($st['derived_py_best'])?(int)round((float)$st['derived_py_best']):'';
      $n=isset($st['n'])?intval($st['n']):'';
      $low=isset($st['low'])?round((float)$st['low'],2):'';
      $high=isset($st['high'])?round((float)$st['high'],2):'';
      echo '<tr><td>'.esc_html($cls).'</td><td>'.esc_html($sct).'</td><td>'.esc_html($py).'</td><td>'.esc_html($py_rya).'</td><td>'.esc_html($py_best).'</td><td>'.esc_html($n).'</td><td>'.esc_html($low).'</td><td>'.esc_html($high).'</td></tr>';
    }
    echo '</tbody></table>';
  } else echo '<p><em>No class stats saved for this race yet.</em></p>';

  echo '<h2>Imported Results</h2>';
  if(is_array($rows)&&!empty($rows)){
    // Map columns with multiple possible names (case-insensitive)
    $col_aliases = [
      'Rank' => ['rank', 'pos', 'position', 'place'],
      'Sail Number' => ['sailno', 'sail no', 'sail_no', 'sail number', 'sailnumber', 'sail', 'sail num', 'sail_num'],
      // NOTE: Do not include "crew" here or it can steal the helm match when both exist.
      'Helm Name' => ['helm name', 'helm_name', 'help_name', 'helm', 'helmname', 'helmsman', 'helmer', 'skipper', 'skipper name', 'driver', 'name', 'helm name '],
      'Crew Name' => ['crew name', 'crew_name', 'crew', 'crew name '],
      'Class' => ['class', 'boatclass', 'boat class', 'division', 'fleet'],
      'Config.' => ['config', 'configuration', 'rig', 'type'],
      'PY' => ['py', 'gl', 'handicap', 'rating', 'yardstick'],
      'Achieved PY' => ['achieved py', 'actual_py', 'corrected_py', 'py used', 'used py', 'achieved'],
      'Laps' => ['laps', 'lap', 'laps_norm'],
      'Elapsed' => ['elapsed', 'elapsed time', 'elapsed_time', 'finish', 'time', 'total time', 'total', 'elapsed time '],
      'Corr.' => ['corr.', 'corr', 'corrected', 'corrected time', 'corrected_time', 'corr time', 'corr_time', 'correctedtime', 'corrected time '],
      'PY Diff.' => ['py diff', 'py_difference', 'difference'],
    ];

    // gather union of all column names (some derived columns may only appear in later rows)
    $data_cols = [];
    foreach ($rows as $r) {
      $data_cols = array_merge($data_cols, array_keys($r));
    }
    $data_cols = array_values(array_unique($data_cols));
    $col_found = [];
    
    // Find matching columns (case-insensitive with canonical form)
    foreach ($data_cols as $dcol) {
      $dcol_str = (string)$dcol;
      $dcol_lower = strtolower($dcol_str);
      $canon = preg_replace('/[^a-z0-9]/','', $dcol_lower);
      foreach ($col_aliases as $label => $patterns) {
        if (isset($col_found[$label])) continue; // Already found
        foreach ($patterns as $pattern) {
          if ($dcol_lower === $pattern) {
            $col_found[$label] = $dcol_str;
            break 2;
          }
          // also try canonical match in case of spaces/punctuation
          $patcanon = preg_replace('/[^a-z0-9]/','', strtolower($pattern));
          if ($patcanon !== '' && $patcanon === $canon) {
            $col_found[$label] = $dcol_str;
            break 2;
          }
        }
      }
    }
    
    // Special handling for derived columns (these have parentheses)
    foreach ($data_cols as $dcol) {
      $dcol_lower = strtolower((string)$dcol);
      if (strpos($dcol_lower, 'derived py/gl') !== false) {
        if (strpos($dcol_lower, 'all') !== false) {
          $col_found['Derived PY/GL (All)'] = $dcol;
        } elseif (strpos($dcol_lower, 'best') !== false) {
          $col_found['Derived PY/GL (Best)'] = $dcol;
        } elseif (strpos($dcol_lower, 'rya') !== false) {
          $col_found['Derived PY/GL (RYA)'] = $dcol;
        }
      } elseif (strpos($dcol_lower, 'excluded') !== false && strpos($dcol_lower, 'py') === false) {
        if (strpos($dcol_lower, 'all') !== false) {
          $col_found['Excluded (All)'] = $dcol;
        } elseif (strpos($dcol_lower, 'best') !== false) {
          $col_found['Excluded (Best)'] = $dcol;
        } elseif (strpos($dcol_lower, 'rya') !== false) {
          $col_found['Excluded (RYA)'] = $dcol;
        }
      }
    }

    // Ensure we always have a corrected-time column so we can display it and sort by it.
    // If the import didn't include Corr, compute corrected-per-lap from Elapsed, Laps and PY.
    if (!isset($col_found['Corr.'])) {
      $col_found['Corr.'] = 'Corr.';
      foreach ($rows as &$row) {
        $elapsed_raw = '';
        if (isset($col_found['Elapsed'])) {
          $elapsed_raw = $row[$col_found['Elapsed']] ?? '';
        } elseif (isset($row['Elapsed'])) {
          $elapsed_raw = $row['Elapsed'];
        }
        $elapsed_val = is_numeric($elapsed_raw) ? floatval($elapsed_raw) : srp_time_to_seconds($elapsed_raw);
        if ($elapsed_val === null) $elapsed_val = 0.0;

        $laps_raw = '1';
        if (isset($col_found['Laps'])) {
          $laps_raw = $row[$col_found['Laps']] ?? '1';
        } elseif (isset($row['Laps'])) {
          $laps_raw = $row['Laps'];
        }
        $laps_val = intval(preg_replace('/\D+/', '', (string)$laps_raw));
        if ($laps_val <= 0) $laps_val = 1;

        $py_raw = 1000.0;
        if (isset($col_found['PY'])) {
          $py_raw = $row[$col_found['PY']] ?? 1000;
        } elseif (isset($row['PY'])) {
          $py_raw = $row['PY'];
        }
        $py_val = floatval(preg_replace('/[^0-9.]/', '', (string)$py_raw));

        $row['Corr.'] = ($elapsed_val > 0 && $py_val > 0) ? (int) round(($elapsed_val / $laps_val) * (1000.0 / $py_val)) : '';
      }
      unset($row);

      // Final partition: always render valid/included rows first, excluded/invalid rows last.
      $rows_good = [];
      $rows_bad = [];
      foreach ($rows as $row) {
        $row_ex = false;
        foreach (['Excluded manual','Excluded (All)','Excluded (Best)','Excluded (RYA)'] as $ek) {
          if (isset($row[$ek]) && strcasecmp((string)$row[$ek], 'Yes') === 0) { $row_ex = true; break; }
        }
        $corr_raw = $row[$col_found['Corr.']] ?? '';
        $corr_val = is_numeric($corr_raw) ? floatval($corr_raw) : (function_exists('srp_time_to_seconds') ? srp_time_to_seconds($corr_raw) : null);
        if ($row_ex || $corr_val === null || $corr_val <= 0) $rows_bad[] = $row;
        else $rows_good[] = $row;
      }
      $rows = array_merge($rows_good, $rows_bad);
    }

    // Build final header list
    $headers = ['Rank'];
    foreach (['Sail Number', 'Helm Name', 'Crew Name', 'Class', 'Config.', 'PY', 'Achieved PY', 'Laps', 'Elapsed', 'Corr.', 'PY Diff.'] as $lbl) {
      if (isset($col_found[$lbl])) $headers[] = $lbl;
    }
    // Add all available derived PY columns
    if (isset($col_found['Derived PY/GL (All)'])) $headers[] = 'Achieved PY (All/SD)';
    if (isset($col_found['Derived PY/GL (Best)'])) $headers[] = 'Achieved PY (Best)';
    if (isset($col_found['Derived PY/GL (RYA)'])) $headers[] = 'Achieved PY (RYA 66%)';
    if (isset($col_found['Excluded (All)'])) $headers[] = 'Excluded (All)';
    if (isset($col_found['Excluded (Best)'])) $headers[] = 'Excluded (Best)';
    if (isset($col_found['Excluded (RYA)'])) $headers[] = 'Excluded (RYA)';
    
    $headers[] = 'Actions';
    $editable = ['Elapsed', 'PY'];

    // Hide only manually excluded / invalid rows from the visible results table.
    // Keep boats that are excluded under one method (e.g. RYA 66%) visible, because
    // they may still be valid for All/SD or Best calculations.
    $rows_visible = [];
    foreach ($rows as $r) {
      $manual_excluded = false;
      foreach (['Excluded manual','Manual Excluded'] as $ek) {
        if (isset($r[$ek]) && strcasecmp((string)$r[$ek], 'Yes') === 0) { $manual_excluded = true; break; }
      }

      $corr_raw = isset($col_found['Corr.']) ? ($r[$col_found['Corr.']] ?? '') : '';
      $corr_val = is_numeric($corr_raw) ? floatval($corr_raw) : (function_exists('srp_time_to_seconds') ? srp_time_to_seconds($corr_raw) : null);

      // Rows with no usable corrected value and excluded in all methods are treated as non-starters (OCS/DNS/DNF etc.)
      $all_methods_excluded = true;
      foreach (['Excluded (All)','Excluded (Best)','Excluded (RYA)'] as $ek) {
        if (!isset($r[$ek]) || strcasecmp((string)$r[$ek], 'Yes') !== 0) { $all_methods_excluded = false; break; }
      }

      if ($manual_excluded) continue;
      if (($corr_val === null || $corr_val <= 0) && $all_methods_excluded) continue;

      $rows_visible[] = $r;
    }
    $rows = $rows_visible;

    echo '<table id="srp_race_rows" class="widefat striped"><thead><tr>';
    foreach($headers as $h) echo '<th>'.esc_html($h).'</th>';
    echo '</tr></thead><tbody>';
    
    // Always sort rows by corrected time ASC (race order = Corr ASC)
    usort($rows, function($a,$b) use ($col_found) {
      $av = floatval($a[$col_found['Corr.']] ?? 0);
      $bv = floatval($b[$col_found['Corr.']] ?? 0);
      return $av <=> $bv;
    });

    foreach($rows as $idx=>$r){
      $is_ex = ((isset($r['Excluded']) && $r['Excluded']==='Yes') || (isset($r['Excluded (All)']) && $r['Excluded (All)']==='Yes'));
      $tr_class = ($is_ex ? ' class="srp-excluded-row"' : '');
      echo '<tr data-row-idx="'.(int)$idx.'"'.$tr_class.'>';
      
      foreach($headers as $h){
        if($h==='Rank'){
          echo '<td>'.esc_html((int)($idx+1)).'</td>';
        } elseif($h==='PY Diff.'){
          // Calculate difference: Achieved PY - Derived PY (All)
          $achieved = isset($col_found['Achieved PY']) ? floatval($r[$col_found['Achieved PY']] ?? 0) : 0;
          $derived = isset($col_found['Derived PY/GL (All)']) ? floatval($r[$col_found['Derived PY/GL (All)']] ?? 0) : 0;
          $diff = $achieved - $derived;
          echo '<td>'.esc_html(($diff !== 0) ? number_format($diff, 1) : '').'</td>';
        } elseif($h==='Achieved PY (All/SD)'){
          $val = isset($col_found['Derived PY/GL (All)']) ? (int)round((float)($r[$col_found['Derived PY/GL (All)']] ?? 0)) : '';
          echo '<td><strong>'.esc_html($val).'</strong></td>';
        } elseif($h==='Achieved PY (Best)'){
          $val = isset($col_found['Derived PY/GL (Best)']) ? (int)round((float)($r[$col_found['Derived PY/GL (Best)']] ?? 0)) : '';
          echo '<td><strong>'.esc_html($val).'</strong></td>';
        } elseif($h==='Achieved PY (RYA 66%)'){
          $val = isset($col_found['Derived PY/GL (RYA)']) ? (int)round((float)($r[$col_found['Derived PY/GL (RYA)']] ?? 0)) : '';
          echo '<td><strong>'.esc_html($val).'</strong></td>';
        } elseif(strpos($h, 'Excluded') !== false && isset($col_found[$h])){
          echo '<td>'.esc_html($r[$col_found[$h]] ?? '').'</td>';
        } elseif($h==='Actions'){
          echo '<td><button type="button" class="button button-primary srp-row-save" disabled>Save</button></td>';
        } elseif(isset($col_found[$h])){
          $cell_val = $r[$col_found[$h]] ?? '';
          $cell = is_array($cell_val) ? '' : (string)$cell_val;
          if(in_array($h,$editable,true)){
            echo '<td><input type="text" class="srp-edit" data-field="'.esc_attr($col_found[$h]).'" value="'.esc_attr($cell).'" style="width:100%" /></td>';
          } else {
            echo '<td>'.esc_html($cell).'</td>';
          }
        } else {
          echo '<td></td>';
        }
      }
      echo '</tr>';
    }
    echo '</tbody></table>';

    // DataTables + sticky header (FixedHeader extension isn't always bundled)
    $corr_col_idx = array_search('Corr.', $headers, true);
    if ($corr_col_idx === false) $corr_col_idx = 0;
    $nonce = wp_create_nonce('srp_row_edit');
    echo '<script>jQuery(function($){
      if($.fn.DataTable){
        var corrIdx = '.(int)$corr_col_idx.';
        $("#srp_race_rows").DataTable({paging:false, searching:true, info:true, scrollY:"60vh", scrollCollapse:true, scrollX:true, order:[[corrIdx,"asc"]]});
        if($("#srp_race_class_stats").length) $("#srp_race_class_stats").DataTable({paging:false,searching:false,info:false, scrollY:false});
      }

      // Sticky headers
      $("<style>#srp_race_rows thead th, #srp_race_class_stats thead th{position:sticky;top:0;background:#fff;z-index:3;}#srp_race_rows_wrapper .dataTables_scrollHead{overflow:visible!important;}</style>").appendTo("head");

      var nonce = '.wp_json_encode($nonce).';
      var postId = '.(int)$post_id.';

      function markDirty($tr){ $tr.addClass("srp-dirty"); $tr.find(".srp-row-save").prop("disabled", false); }
      $(document).on("input change", ".srp-edit, .srp-manual-ex", function(){ markDirty($(this).closest("tr")); });

      $(document).on("click", ".srp-row-save", function(){
        var $btn=$(this); var $tr=$btn.closest("tr");
        var rowIdx=parseInt($tr.data("row-idx"),10);
        var fields={};
        $tr.find(".srp-edit").each(function(){ fields[$(this).data("field")]= $(this).val(); });
        var manualExcluded = $tr.find(".srp-manual-ex").is(":checked") ? "1" : "0";
        $btn.prop("disabled", true).text("Saving...");
        $.post(ajaxurl,{action:"srp_save_row_edit",nonce:nonce,post_id:postId,row_idx:rowIdx,fields:fields,manual_excluded:manualExcluded})
          .done(function(resp){ if(resp && resp.success){ window.location.reload(); }
            else { alert((resp&&resp.data&&resp.data.message)?resp.data.message:"Save failed"); $btn.prop("disabled",false).text("Save"); }} )
          .fail(function(){ alert("Save failed"); $btn.prop("disabled",false).text("Save"); });
      });
    });</script>';
  } else echo '<p><em>No rows saved.</em></p>';

  echo '</div>';
}

/**
 * Merge class stats from dual-analysis result to combine all three PY calculation methods
 *
 * @param array $stats_result Result returned by srp_compute_dual_v2()
 * @return array Merged class stats array
 */
function srp_merge_dual_class_stats(array $stats_result) {
  if (!is_array($stats_result)) return [];
  
  $all_stats = $stats_result['all']['class_stats'] ?? [];
  $best_stats = $stats_result['best']['class_stats'] ?? [];
  $rya_stats = $stats_result['rya']['class_stats'] ?? [];
  
  $merged = [];
  
  // Collect all class names
  $all_classes = array_unique(array_merge(
    array_keys($all_stats),
    array_keys($best_stats),
    array_keys($rya_stats)
  ));
  
  foreach ($all_classes as $class_name) {
    $merged[$class_name] = [
      'derived_py' => isset($all_stats[$class_name]['derived_py']) ? $all_stats[$class_name]['derived_py'] : null,
      'derived_py_rya' => isset($rya_stats[$class_name]['derived_py']) ? $rya_stats[$class_name]['derived_py'] : null,
      'derived_py_best' => isset($best_stats[$class_name]['derived_py']) ? $best_stats[$class_name]['derived_py'] : null,
      'derived_gl' => isset($all_stats[$class_name]['derived_gl']) ? $all_stats[$class_name]['derived_gl'] : null,
      'sct' => isset($all_stats[$class_name]['sct']) ? $all_stats[$class_name]['sct'] : null,
      'n' => isset($all_stats[$class_name]['n']) ? $all_stats[$class_name]['n'] : null,
      'k' => isset($all_stats[$class_name]['k']) ? $all_stats[$class_name]['k'] : 2.0,
    ];
  }
  
  return $merged;
}
function srp_merge_dual_rows(array $stats_result) {
  if (!is_array($stats_result) || !isset($stats_result['all'])) return [];
  $all_rows  = $stats_result['all']['rows']  ?? [];
  $best_rows = $stats_result['best']['rows'] ?? [];
  $rya_rows  = $stats_result['rya']['rows']  ?? [];
  if (empty($all_rows)) return [];
  foreach ($all_rows as $idx => &$row) {
    if (isset($best_rows[$idx])) {
      if (isset($best_rows[$idx]['Derived PY/GL (Best)'])) $row['Derived PY/GL (Best)'] = $best_rows[$idx]['Derived PY/GL (Best)'];
      if (isset($best_rows[$idx]['Excluded (Best)']))    $row['Excluded (Best)']    = $best_rows[$idx]['Excluded (Best)'];
      if (isset($best_rows[$idx]['Exclusion Reason (Best)'])) $row['Exclusion Reason (Best)'] = $best_rows[$idx]['Exclusion Reason (Best)'];
    }
    if (isset($rya_rows[$idx])) {
      if (isset($rya_rows[$idx]['Derived PY/GL (RYA)'])) $row['Derived PY/GL (RYA)'] = $rya_rows[$idx]['Derived PY/GL (RYA)'];
      if (isset($rya_rows[$idx]['Excluded (RYA)']))    $row['Excluded (RYA)']    = $rya_rows[$idx]['Excluded (RYA)'];
      if (isset($rya_rows[$idx]['Exclusion Reason (RYA)'])) $row['Exclusion Reason (RYA)'] = $rya_rows[$idx]['Exclusion Reason (RYA)'];
    }
  }
  unset($row);
  return $all_rows;
}

function srp_render_import_ui(array $opts) {
  $context=$opts['context']??'admin';
  $action=isset($_POST['srp_action'])?sanitize_text_field(wp_unslash($_POST['srp_action'])):'parse';
  $html=isset($_POST['srp_html'])?wp_unslash($_POST['srp_html']):'';
  $raceid=isset($_POST['srp_raceid'])?sanitize_text_field(wp_unslash($_POST['srp_raceid'])):'';

  $parse_result=null; $race_result=null; $course_result=null; $marks_result=null; $stats_result=null;
  $saved_post_id=null; $error='';

  $posted_context=isset($_POST['srp_context'])?sanitize_text_field(wp_unslash($_POST['srp_context'])):'';
  $should_handle=($_SERVER['REQUEST_METHOD']==='POST' && $posted_context===$context);

  if($should_handle){
    if(!isset($_POST['srp_nonce'])||!wp_verify_nonce($_POST['srp_nonce'],'srp_parse_'.$context)) $error='Security check failed.';
    else if($raceid===''||!preg_match('/^\d+$/',$raceid)) $error='Please enter a numeric TT raceid.';
    else if(trim($html)==='') $error='Please paste some HTML (must include a results table).';
    else{
      $parse_result=srp_parse_results_html($html);
      if(!empty($parse_result['error'])) $error=$parse_result['error'];
      else{
        $race_result=srp_tt_fetch_race_details($raceid);
        $course_result=srp_tt_fetch_course($raceid);
        $marks_result=srp_tt_fetch_marks($raceid);

        $k=floatval(get_option('srp_outlier_k',2.0));
        $stats_result=(function_exists('srp_compute_dual_v2') ? srp_compute_dual_v2($parse_result['rows'],$k) : srp_compute_allboats($parse_result['rows'],$k));
        // Merge all three methodology results into a single row array for display
        if (is_array($stats_result) && isset($stats_result['all'])) {
          $parse_result['rows'] = srp_merge_dual_rows($stats_result);
        } elseif(!empty($stats_result['rows'])) {
          $parse_result['rows']=$stats_result['rows'];
        }

        if($action==='save'){
          $saved_post_id=srp_save_or_update_import($raceid,$html,$parse_result,$race_result,$course_result,$marks_result,$stats_result);
          if(is_wp_error($saved_post_id)){ $error=$saved_post_id->get_error_message(); $saved_post_id=null; }
        }
      }
    }
  }

  if($error){
    echo '<div class="notice notice-error"><p>'.esc_html($error).'</p></div>';
  } elseif($saved_post_id){
    $view=admin_url('admin.php?page=srp-race-view&post_id='.intval($saved_post_id));
    echo '<div class="notice notice-success"><p>Saved import (created/updated). <a href="'.esc_url($view).'">Open race view</a></p></div>';
  }

  echo '<form method="post">';
  wp_nonce_field('srp_parse_'.$context,'srp_nonce');
  echo '<input type="hidden" name="srp_context" value="'.esc_attr($context).'" />';
  echo '<p><label><strong>TT raceid</strong></label><br/><input type="text" name="srp_raceid" value="'.esc_attr($raceid).'" class="regular-text" /></p>';
  echo '<p><strong>Results HTML</strong></p>';

  $settings=['textarea_name'=>'srp_html','textarea_rows'=>18,'media_buttons'=>false,'teeny'=>true,'tinymce'=>['wpautop'=>false,'forced_root_block'=>false,'toolbar1'=>'bold,italic,underline,|,bullist,numlist,|,removeformat,|,undo,redo,|,code','toolbar2'=>''],'quicktags'=>true];
  wp_editor($html,'srp_html_editor_'.$context,$settings);

  echo '<p><button type="submit" class="button button-secondary" name="srp_action" value="parse">Parse</button> <button type="submit" class="button button-primary" name="srp_action" value="save">Save</button></p>';
  echo '</form>';

  if(is_array($parse_result)){
    echo '<h2>Preview</h2>';
    if(!empty($parse_result['rows'])){
      $headers=array_keys($parse_result['rows'][0]);
      $headers = array_values(array_filter($headers, function($h){ return !in_array($h, ['Derived PY','Derived GL'], true); }));
      echo '<div style="overflow:auto; max-width:100%;"><table class="widefat striped"><thead><tr>';
      foreach($headers as $h) echo '<th>'.esc_html($h).'</th>';
      echo '</tr></thead><tbody>';
      foreach($parse_result['rows'] as $row){ echo '<tr>'; foreach($headers as $h) { $val = is_array($row[$h] ?? '') ? '' : ($row[$h] ?? ''); echo '<td>'.esc_html($val).'</td>'; } echo '</tr>'; }
      echo '</tbody></table></div>';
    } else echo '<p><em>No rows could be extracted.</em></p>';
  }
}

function srp_find_import_post_id_by_raceid($raceid) {
  $q=new WP_Query(['post_type'=>'srp_import','post_status'=>['private'],'posts_per_page'=>1,'meta_key'=>'srp_raceid','meta_value'=>$raceid,'fields'=>'ids']);
  if(!empty($q->posts)) return (int)$q->posts[0];
  return 0;
}

function srp_save_or_update_import($raceid,$html,array $parse_result,$race_result,$course_result,$marks_result,$stats_result) {
  $race_name='';
  if(is_array($race_result)&&empty($race_result['error'])){
    if(!empty($race_result['raceName'])) $race_name=(string)$race_result['raceName'];
    if($race_name===''&&!empty($race_result['name'])) $race_name=(string)$race_result['name'];
  }
  $title='TT Race '.$raceid.($race_name?' — '.$race_name:'');
  $existing_id=srp_find_import_post_id_by_raceid($raceid);
  if($existing_id) $post_id=wp_update_post(['ID'=>$existing_id,'post_title'=>$title,'post_status'=>'private','post_type'=>'srp_import'],true);
  else $post_id=wp_insert_post(['post_type'=>'srp_import','post_status'=>'private','post_title'=>$title],true);
  if(is_wp_error($post_id)) return $post_id;

  update_post_meta($post_id,'srp_raceid',$raceid);
  update_post_meta($post_id,'srp_race_name',$race_name);
  update_post_meta($post_id,'srp_raw_html',$html);

  // Calculate corrected time if not present in parsed data
  $rows = $parse_result['rows'];
  if (!empty($rows) && !isset($rows[0]['Corr.'])) {
    foreach ($rows as &$row) {
      $elapsed_raw = $row['Elapsed'] ?? '';
      $elapsed = is_numeric($elapsed_raw) ? floatval($elapsed_raw) : (function_exists('srp_time_to_seconds') ? srp_time_to_seconds($elapsed_raw) : 0);
      $laps = isset($row['Laps']) && is_numeric($row['Laps']) ? floatval($row['Laps']) : 1;
      if ($laps <= 0) $laps = 1;
      $py = isset($row['PY']) && is_numeric($row['PY']) ? floatval($row['PY']) : 1000;
      $row['Corr.'] = ($elapsed > 0 && $py > 0) ? (int)round((1000.0 / $py) * ($elapsed / $laps)) : '';
    }
    unset($row);
  }
  update_post_meta($post_id,'srp_parsed_rows',wp_json_encode($rows));

  if(is_array($race_result)&&empty($race_result['error'])) update_post_meta($post_id,'srp_tt_race_details',wp_json_encode($race_result));
  if(is_array($course_result)&&empty($course_result['error'])) update_post_meta($post_id,'srp_tt_course',wp_json_encode($course_result));
  if(is_array($marks_result)&&empty($marks_result['error'])) update_post_meta($post_id,'srp_tt_marks',wp_json_encode($marks_result));

  if(is_array($stats_result)&&isset($stats_result['all'])){
    update_post_meta($post_id,'srp_analysis_dual',wp_json_encode($stats_result));
    if(!empty($stats_result['all']['class_stats'])){
      $merged = srp_merge_dual_class_stats($stats_result);
      srp_upsert_class_stats($merged);
      update_post_meta($post_id,'srp_class_stats',wp_json_encode($merged));
    }
  } elseif(is_array($stats_result)&&!empty($stats_result['class_stats'])){
    srp_upsert_class_stats($stats_result['class_stats']);
    update_post_meta($post_id,'srp_class_stats',wp_json_encode($stats_result['class_stats']));
  }

  if (function_exists('srp_db_sync_post_to_tables')) {
    srp_db_sync_post_to_tables($post_id);
    srp_db_rebuild_class_summary();
  }

  return $post_id;
}





function srp_class_races_page(){
  if (!current_user_can('manage_options')) return;
  global $wpdb;
  $class = isset($_GET['class']) ? sanitize_text_field($_GET['class']) : '';
  $start_date = isset($_GET['srp_start']) ? sanitize_text_field((string)$_GET['srp_start']) : '';
  $end_date   = isset($_GET['srp_end']) ? sanitize_text_field((string)$_GET['srp_end']) : '';
  if ($class === '') { echo '<div class="wrap"><h1>No class specified</h1></div>'; return; }

  $races_table = srp_db_table('srp_races');
  $results_table = srp_db_table('srp_results');

  $where = ["r.class_name = %s"];
  $params = [$class];
  if ($start_date !== '') { $where[] = "rr.race_start >= %s"; $params[] = $start_date . ' 00:00:00'; }
  if ($end_date !== '') { $where[] = "rr.race_start <= %s"; $params[] = $end_date . ' 23:59:59'; }
  $where_sql = implode(' AND ', $where);

  $sql = "SELECT rr.id AS race_db_id, rr.post_id, rr.race_name, rr.race_start,
                 AVG(CASE WHEN r.excluded_manual=0 AND r.excluded_all=0 THEN r.derived_py_all END) AS avg_all,
                 AVG(CASE WHEN r.excluded_manual=0 AND r.excluded_best=0 THEN r.derived_py_best END) AS avg_best,
                 AVG(CASE WHEN r.excluded_manual=0 AND r.excluded_rya=0 THEN r.derived_py_rya END) AS avg_rya,
                 SUM(CASE WHEN r.excluded_manual=1 OR r.excluded_all=1 OR r.excluded_best=1 OR r.excluded_rya=1 THEN 1 ELSE 0 END) AS exclusions
          FROM $races_table rr
          INNER JOIN $results_table r ON r.race_db_id = rr.id
          WHERE $where_sql
          GROUP BY rr.id, rr.post_id, rr.race_name, rr.race_start
          ORDER BY rr.race_start DESC, rr.id DESC";
  $sql = $wpdb->prepare($sql, ...$params);
  $rows = $wpdb->get_results($sql, ARRAY_A);

  $back_url = admin_url('admin.php?page=srp-class-stats');
  if ($start_date !== '') $back_url = add_query_arg(['srp_start' => $start_date], $back_url);
  if ($end_date !== '') $back_url = add_query_arg(['srp_end' => $end_date], $back_url);

  echo '<div class="wrap"><h1>Races for ' . esc_html($class) . '</h1>';
  echo '<p><a href="' . esc_url($back_url) . '">Back to Class Report</a></p>';
  echo '<table id="srp_class_races" class="widefat striped">';
  echo '<thead><tr><th>Race Name</th><th>Date</th><th>PY (All/SD)</th><th>PY (RYA 66%)</th><th>PY (Best)</th><th>Exclusions</th><th>Actions</th></tr></thead><tbody>';
  foreach ($rows as $r) {
    $race_name = (string)($r['race_name'] ?: ('Race #' . $r['race_db_id']));
    $date = !empty($r['race_start']) ? date('Y-m-d', strtotime((string)$r['race_start'])) : '';
    $view_url = admin_url('admin.php?page=srp-race-view&post_id=' . intval($r['post_id']));
    echo '<tr>';
    echo '<td>' . esc_html($race_name) . '</td>';
    echo '<td>' . esc_html($date) . '</td>';
    echo '<td>' . esc_html($r['avg_all'] !== null ? (int)round((float)$r['avg_all']) : '') . '</td>';
    echo '<td>' . esc_html($r['avg_rya'] !== null ? (int)round((float)$r['avg_rya']) : '') . '</td>';
    echo '<td>' . esc_html($r['avg_best'] !== null ? (int)round((float)$r['avg_best']) : '') . '</td>';
    echo '<td>' . esc_html(intval($r['exclusions'])) . '</td>';
    echo '<td><a href="' . esc_url($view_url) . '">View</a></td>';
    echo '</tr>';
  }
  echo '</tbody></table>';
  echo "<script>jQuery(function($){ if($.fn.DataTable){ $('#srp_class_races').DataTable({paging:false, pageLength:1000, order:[[1,'desc']]}); } });</script>";
  echo '</div>';
}


function srp_class_graph_page(){
  if (!current_user_can('manage_options')) return;
  global $wpdb;
  $class = isset($_GET['class']) ? sanitize_text_field($_GET['class']) : '';
  $start_date = isset($_GET['srp_start']) ? sanitize_text_field((string)$_GET['srp_start']) : '';
  $end_date   = isset($_GET['srp_end']) ? sanitize_text_field((string)$_GET['srp_end']) : '';
  if (!$class){
    echo '<div class="wrap"><h1>No class specified</h1></div>';
    return;
  }

  $races_table = srp_db_table('srp_races');
  $results_table = srp_db_table('srp_results');

  $where = ["r.class_name = %s"];
  $params = [$class];
  if ($start_date !== '') { $where[] = "rr.race_start >= %s"; $params[] = $start_date . ' 00:00:00'; }
  if ($end_date !== '') { $where[] = "rr.race_start <= %s"; $params[] = $end_date . ' 23:59:59'; }
  $where_sql = implode(' AND ', $where);

  $sql = "SELECT rr.id AS race_db_id, rr.race_start,
                 AVG(CASE WHEN r.excluded_manual=0 AND r.excluded_all=0 THEN r.derived_py_all END) AS derived_all,
                 AVG(CASE WHEN r.excluded_manual=0 AND r.excluded_best=0 THEN r.derived_py_best END) AS derived_best,
                 AVG(CASE WHEN r.excluded_manual=0 AND r.excluded_rya=0 THEN r.derived_py_rya END) AS derived_rya,
                 AVG(r.py) AS actual
          FROM $races_table rr
          INNER JOIN $results_table r ON r.race_db_id = rr.id
          WHERE $where_sql
          GROUP BY rr.id, rr.race_start
          ORDER BY rr.race_start ASC, rr.id ASC";
  $sql = $wpdb->prepare($sql, ...$params);
  $rows = $wpdb->get_results($sql, ARRAY_A);

  $points = [];
  foreach ($rows as $r){
    $ts = !empty($r['race_start']) ? strtotime((string)$r['race_start']) : 0;
    if (!$ts) continue;
    $points[] = [
      'ts' => $ts,
      'derived' => ($r['derived_all'] !== null ? (int)round((float)$r['derived_all']) : null),
      'derived_best' => ($r['derived_best'] !== null ? (int)round((float)$r['derived_best']) : null),
      'derived_rya' => ($r['derived_rya'] !== null ? (int)round((float)$r['derived_rya']) : null),
      'actual' => ($r['actual'] !== null ? (int)round((float)$r['actual']) : null),
    ];
  }

  $dates=[]; $derived_all_vals=[]; $derived_best_vals=[]; $derived_rya_vals=[]; $actual_vals=[]; $x=[];
  foreach ($points as $i=>$p){
    $dates[] = date('Y-m-d', intval($p['ts']));
    $derived_all_vals[] = $p['derived'];
    $derived_best_vals[] = $p['derived_best'];
    $derived_rya_vals[] = $p['derived_rya'];
    $actual_vals[] = $p['actual'];
    $x[] = $i;
  }

  $make_trend = function($series) use ($x){
    $trend=[]; $n=count($x);
    if ($n<=1) return $trend;
    $xs=[]; $ys=[];
    for($i=0;$i<$n;$i++){ if (!isset($series[$i]) || $series[$i] === null) continue; $xs[]=$x[$i]; $ys[]=$series[$i]; }
    $nn=count($xs); if ($nn<=1) return $trend;
    $sumx=array_sum($xs); $sumy=array_sum($ys); $sumxy=0; $sumxx=0;
    for($i=0;$i<$nn;$i++){ $sumxy += $xs[$i]*$ys[$i]; $sumxx += $xs[$i]*$xs[$i]; }
    $den = ($nn*$sumxx - $sumx*$sumx); if ($den == 0) return $trend;
    $m = ($nn*$sumxy - $sumx*$sumy)/$den; $b = ($sumy - $m*$sumx)/$nn;
    for($i=0;$i<$n;$i++){ $trend[] = (!isset($series[$i]) || $series[$i] === null) ? null : ($m*$x[$i] + $b); }
    return $trend;
  };
  $trend = $make_trend($derived_all_vals);
  $trend_best = $make_trend($derived_best_vals);
  $trend_rya = $make_trend($derived_rya_vals);

  wp_enqueue_script('srp-chartjs', 'https://cdn.jsdelivr.net/npm/chart.js', [], null, true);
  $inline = 'document.addEventListener("DOMContentLoaded",function(){'
    . 'var el=document.getElementById("srp_py_chart"); if(!el) return;'
    . 'if(typeof Chart==="undefined"){ return; }'
    . 'var labels=' . wp_json_encode($dates) . ';'
    . 'var derived=' . wp_json_encode($derived_all_vals) . ';'
    . 'var derived_best=' . wp_json_encode($derived_best_vals) . ';'
    . 'var derived_rya=' . wp_json_encode($derived_rya_vals) . ';'
    . 'var actual=' . wp_json_encode($actual_vals) . ';'
    . 'var trend=' . wp_json_encode($trend) . ';'
    . 'var trend_best=' . wp_json_encode($trend_best) . ';'
    . 'var trend_rya=' . wp_json_encode($trend_rya) . ';'
    . 'new Chart(el,{type:"line",data:{labels:labels,datasets:['
    . '{label:"Derived PY (Allboats SD)",data:derived,tension:0.1},'
    . '{label:"Derived PY (Best-of-class)",data:derived_best,tension:0.1},'
    . '{label:"Derived PY (RYA 66%)",data:derived_rya,tension:0.1},'
    . '{label:"Actual PY used",data:actual,tension:0.1},'
    . '{label:"Trendline (Allboats derived)",data:trend,borderDash:[5,5],tension:0.1},'
    . '{label:"Trendline (Best)",data:trend_best,borderDash:[5,5],tension:0.1},'
    . '{label:"Trendline (RYA)",data:trend_rya,borderDash:[5,5],tension:0.1}'
    . ']},options:{responsive:true,plugins:{legend:{display:true}},scales:{y:{title:{display:true,text:"PY"}}}}});'
    . '});';
  wp_add_inline_script('srp-chartjs', $inline);

  $back_url = admin_url('admin.php?page=srp-class-stats');
  if ($start_date !== '') $back_url = add_query_arg(['srp_start' => $start_date], $back_url);
  if ($end_date !== '') $back_url = add_query_arg(['srp_end' => $end_date], $back_url);
  if ($class !== '') $back_url = add_query_arg(['srp_class' => $class], $back_url);

  echo '<div class="wrap">';
  echo '<h1>' . esc_html($class) . ' – PY over time</h1>';
  echo '<p><a href="' . esc_url($back_url) . '">Back to Class Report</a></p>';
  if (count($dates) < 2) echo '<p>No (or not enough) saved race points for this class yet for the selected filter.</p>';
  echo '<canvas id="srp_py_chart" style="max-width:1100px;height:360px;"></canvas>';
  echo '</div>';
}

function srp_get_rows_meta_array($post_id) {
  $rows_meta = get_post_meta($post_id, 'srp_parsed_rows', true);
  if (is_array($rows_meta)) return $rows_meta;
  $rows = json_decode((string)$rows_meta, true);
  return is_array($rows) ? $rows : [];
}

function srp_recalculate_post_stats($post_id) {
  $rows = srp_get_rows_meta_array($post_id);
  if (empty($rows)) return false;

  $k = floatval(get_option('srp_outlier_k', 2.0));
  $stats_dual = function_exists('srp_compute_dual_v2') ? srp_compute_dual_v2($rows, $k) : srp_compute_dual($rows, $k);
  if (!is_array($stats_dual)) return false;

  update_post_meta($post_id, 'srp_analysis_dual', wp_json_encode($stats_dual));

  $merged_rows = function_exists('srp_merge_dual_rows') ? srp_merge_dual_rows($stats_dual) : (($stats_dual['all']['rows'] ?? []) ?: $rows);
  if (!empty($merged_rows)) {
    update_post_meta($post_id, 'srp_parsed_rows', wp_json_encode($merged_rows));
  }

  $merged_class_stats = function_exists('srp_merge_dual_class_stats') ? srp_merge_dual_class_stats($stats_dual) : ($stats_dual['all']['class_stats'] ?? []);
  if (!empty($merged_class_stats)) {
    srp_upsert_class_stats($merged_class_stats);
    update_post_meta($post_id, 'srp_class_stats', wp_json_encode($merged_class_stats));
  } else {
    update_post_meta($post_id, 'srp_class_stats', wp_json_encode([]));
  }

  if (!empty($stats_dual['all']['debug'])) {
    update_post_meta($post_id, 'srp_stats_debug', wp_json_encode($stats_dual['all']['debug']));
  }

  return true;
}

function srp_tools_page(){
  if (!current_user_can('manage_options')) return;
  echo '<div class="wrap"><h1>SRP Tools</h1>';
  if (isset($_GET['srp_done'])){
    echo '<div class="notice notice-success"><p>Recalculation completed.</p></div>';
  }
  echo '<p>This recalculates SCT / Derived PY/GL for all stored races using the latest logic.</p>';
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-bottom:12px;">';
  echo '<input type="hidden" name="action" value="srp_recalc_all">';
  wp_nonce_field('srp_recalc_all','srp_nonce');
  echo '<p><button class="button button-primary">Recalculate all races</button></p>';
  echo '</form>';
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
  echo '<input type="hidden" name="action" value="srp_migrate_db">';
  wp_nonce_field('srp_migrate_db','srp_db_nonce');
  echo '<p><button class="button">Migrate existing races to DB</button></p>';
  echo '</form></div>';
}

add_action('admin_post_srp_recalc_all', function(){
  if (!current_user_can('manage_options')) wp_die('Not allowed');
  if (!isset($_POST['srp_nonce']) || !wp_verify_nonce($_POST['srp_nonce'], 'srp_recalc_all')) wp_die('Bad nonce');

  $posts = get_posts([
    'post_type' => 'srp_import',
    'post_status' => 'any',
    'numberposts' => -1,
    'fields' => 'ids',
  ]);
  if (is_array($posts)){
    foreach ($posts as $post_id){
      srp_recalculate_post_stats($post_id);
    }
  }
  wp_safe_redirect(add_query_arg(['page'=>'srp-tools','srp_done'=>1], admin_url('admin.php')));
  exit;
});


add_action('admin_post_srp_migrate_db', function(){
  if (!current_user_can('manage_options')) wp_die('Not allowed');
  if (!isset($_POST['srp_db_nonce']) || !wp_verify_nonce($_POST['srp_db_nonce'], 'srp_migrate_db')) wp_die('Bad nonce');
  srp_db_migrate_existing_posts();
  wp_safe_redirect(add_query_arg(['page'=>'srp-tools','srp_done'=>1,'srp_migrated'=>1], admin_url('admin.php')));
  exit;
});

/**
 * Save per-row manual edits (Finish / Elapsed / Laps / GL etc.) and manual exclusion.
 * Recomputes stored SCT/PY/GL immediately so rogue rows cannot pollute class stats.
 */
function srp_ajax_save_row_edit(){
  if (!current_user_can('manage_options')){
    wp_send_json_error(['message' => 'Permission denied'], 403);
  }
  $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
  if (!wp_verify_nonce($nonce, 'srp_row_edit')){
    wp_send_json_error(['message' => 'Bad nonce'], 400);
  }

  $post_id = isset($_POST['post_id']) ? (int)$_POST['post_id'] : 0;
  $row_idx = isset($_POST['row_idx']) ? (int)$_POST['row_idx'] : -1;
  if ($post_id <= 0 || $row_idx < 0){
    wp_send_json_error(['message' => 'Missing post_id/row_idx'], 400);
  }

  $rows = json_decode((string)get_post_meta($post_id, 'srp_parsed_rows', true), true);
  if (!is_array($rows) || !isset($rows[$row_idx]) || !is_array($rows[$row_idx])){
    wp_send_json_error(['message' => 'Row not found'], 404);
  }

  $fields = isset($_POST['fields']) ? (array)$_POST['fields'] : [];
  // Expect a small set of editable columns only.
  $allowed = ['Finish','Elapsed','Laps','GL','Corrected'];
  foreach ($allowed as $k){
    if (array_key_exists($k, $fields)){
      $rows[$row_idx][$k] = sanitize_text_field(wp_unslash((string)$fields[$k]));
    }
  }

  $manual_ex = isset($_POST['manual_excluded']) ? sanitize_text_field(wp_unslash((string)$_POST['manual_excluded'])) : '0';
  $rows[$row_idx]['Excluded manual'] = ($manual_ex === '1' || $manual_ex === 'true' || strcasecmp($manual_ex,'yes')===0) ? 'Yes' : 'No';

  update_post_meta($post_id, 'srp_parsed_rows', wp_json_encode($rows));

  // Recompute dual analysis immediately
  if (function_exists('srp_compute_dual_analysis')){
    $dual = srp_compute_dual_analysis($rows);
    if (is_array($dual)){
      update_post_meta($post_id, 'srp_analysis_dual', $dual);
      if (isset($dual['all']['rows'])) update_post_meta($post_id, 'srp_parsed_rows', wp_json_encode($dual['all']['rows']));
      if (isset($dual['all']['class_stats'])) update_post_meta($post_id, 'srp_class_stats', wp_json_encode($dual['all']['class_stats']));
      if (isset($dual['all']['debug'])) update_post_meta($post_id, 'srp_calc_debug', wp_json_encode($dual['all']['debug']));
    }
  }

  wp_send_json_success(['ok'=>true]);
}


// -------------------------
// Data QA (outlier scanner)
// -------------------------
function srp_data_qa_page(){
  if (!current_user_can('edit_posts')) return;
  $days = isset($_GET['srp_days']) ? max(1, intval($_GET['srp_days'])) : 90;
  $abs_secs = isset($_GET['srp_abs']) ? max(0, intval($_GET['srp_abs'])) : 6*3600; // 6h
  $mult = isset($_GET['srp_mult']) ? max(1.0, floatval($_GET['srp_mult'])) : 3.0;
  $max_races = isset($_GET['srp_max']) ? max(10, intval($_GET['srp_max'])) : 200;

  $since = time() - ($days*86400);
  $q = new WP_Query([
    'post_type' => 'srp_import',
    'posts_per_page' => $max_races,
    'post_status' => ['publish','draft','pending','private'],
    'orderby' => 'modified',
    'order' => 'DESC',
    'meta_query' => [
      [
        'key' => 'srp_race_start',
        'compare' => 'EXISTS',
      ]
    ]
  ]);

  echo '<div class="wrap"><h1>Data QA – Outliers</h1>';
  echo '<form method="get" style="margin:10px 0;">';
  echo '<input type="hidden" name="page" value="srp-data-qa"/>';
  echo 'Look back days <input type="number" name="srp_days" value="'.esc_attr($days).'" style="width:90px;"/> ';
  echo 'Absolute elapsed threshold (sec) <input type="number" name="srp_abs" value="'.esc_attr($abs_secs).'" style="width:120px;"/> ';
  echo 'Median multiplier <input type="number" step="0.1" name="srp_mult" value="'.esc_attr($mult).'" style="width:80px;"/> ';
  echo '<button class="button">Scan</button>';
  echo '</form>';

  echo '<table class="widefat striped"><thead><tr>';
  echo '<th>Race</th><th>Start</th><th>Class</th><th>Sail</th><th>Helm</th><th>Crew</th><th>Laps</th><th>Elapsed</th><th>Elapsed/Lap</th><th>Reason</th><th>Action</th>';
  echo '</tr></thead><tbody>';

  $count=0;
  foreach ($q->posts as $p){
    $post_id = $p->ID;
    $start = get_post_meta($post_id,'srp_race_start',true);
    $start_ts = $start ? strtotime((string)$start) : 0;
    if ($start_ts && $start_ts < $since) continue;

    $rows = srp_load_rows($post_id);
    if (empty($rows)) continue;

    // compute median elapsed/lap per race (numeric only)
    $vals=[];
    foreach ($rows as $r){
      $laps = intval($r['Laps'] ?? $r['laps'] ?? $r['laps_norm'] ?? 0);
      $elapsed = $r['Elapsed'] ?? $r['elapsed'] ?? $r['elapsed_time'] ?? null;
      $elapsed = srp_parse_elapsed_seconds($elapsed);
      if ($laps<=0 || $elapsed<=0) continue;
      $vals[] = $elapsed/$laps;
    }
    if (empty($vals)) continue;
    sort($vals);
    $med = $vals[intval((count($vals)-1)/2)];
    $limit = max($abs_secs, $med*$mult);

    foreach ($rows as $r){
      $laps = intval($r['Laps'] ?? $r['laps'] ?? $r['laps_norm'] ?? 0);
      $elapsed_raw = $r['Elapsed'] ?? $r['elapsed'] ?? $r['elapsed_time'] ?? null;
      $elapsed = srp_parse_elapsed_seconds($elapsed_raw);
      if ($laps<=0 || $elapsed<=0) continue;
      $elp = $elapsed/$laps;
      if ($elapsed > $abs_secs || $elp > $limit){
        $race_name = get_post_meta($post_id,'srp_race_name',true);
        $class = $r['class'] ?? $r['class_name'] ?? $r['Class'] ?? '';
        $sail = $r['sail_number'] ?? $r['sailno'] ?? $r['Sail Number'] ?? '';
        $helm = $r['help_name'] ?? $r['helm_name'] ?? $r['Helm Name'] ?? '';
        $crew = $r['crew_name'] ?? $r['Crew Name'] ?? '';
        $reason = ($elapsed > $abs_secs ? 'Elapsed>abs ' : '').($elp > $limit ? 'Elapsed/lap>limit' : '');
        $view = admin_url('admin.php?page=srp_race_view&post_id='.$post_id.'&srp_view=rya');
        $row_is_excluded = false; foreach (['Excluded manual','Excluded (All)','Excluded (Best)','Excluded (RYA)'] as $ek){ if (isset($row[$ek]) && strcasecmp((string)$row[$ek],'Yes')===0){ $row_is_excluded = true; break; } } echo '<tr' . ($row_is_excluded ? ' style="opacity:.55;"' : '') . '>';
        echo '<td>'.esc_html($race_name ?: ('#'.$post_id)).'</td>';
        echo '<td>'.esc_html($start).'</td>';
        echo '<td>'.esc_html($class).'</td>';
        echo '<td>'.esc_html($sail).'</td>';
        echo '<td>'.esc_html($helm).'</td>';
        echo '<td>'.esc_html($crew).'</td>';
        echo '<td>'.esc_html($laps).'</td>';
        echo '<td>'.esc_html($elapsed).'</td>';
        echo '<td>'.esc_html(round($elp,1)).'</td>';
        echo '<td>'.esc_html($reason).'</td>';
        echo '<td><a class="button" href="'.esc_url($view).'">Open race</a></td>';
        echo '</tr>';
        $count++;
        if ($count>500) break 2;
      }
    }
  }
  if ($count===0){
    echo '<tr><td colspan="11"><em>No outliers found with current thresholds.</em></td></tr>';
  }
  echo '</tbody></table></div>';
}


// Load saved rows meta (supports array/serialized or JSON string)
function srp_load_rows($post_id){
  $raw = get_post_meta($post_id,'srp_parsed_rows',true);
  if (is_array($raw)) return $raw;
  if (is_string($raw) && $raw !== ''){
    $j = json_decode($raw,true);
    if (is_array($j)) return $j;
  }
  return [];
}


// Parse elapsed time formats into seconds (supports 0.37.38, 37:38, 1:02:03, numeric seconds)
function srp_parse_elapsed_seconds($v){
  if ($v === null) return 0;
  if (is_numeric($v)) return (int)round(floatval($v));
  $s = trim((string)$v);
  if ($s === '') return 0;
  // replace dots with colon if looks like time
  if (preg_match('/^\d+\.\d{2}\.\d{2}$/', $s)) $s = str_replace('.',':',$s);
  if (preg_match('/^\d+\.\d{2}$/', $s)) $s = str_replace('.',':',$s);
  if (preg_match('/^(\d+):(\d{2}):(\d{2})$/',$s,$m)){
    return intval($m[1])*3600 + intval($m[2])*60 + intval($m[3]);
  }
  if (preg_match('/^(\d+):(\d{2})$/',$s,$m)){
    return intval($m[1])*60 + intval($m[2]);
  }
  // fallback: strip non-digits
  $num = preg_replace('/[^0-9]/','',$s);
  return $num!=='' ? intval($num) : 0;
}

// Fetch TT race details (cached in post meta)
function srp_tt_get_race_details_cached($post_id, $raceid){
  $raw = get_post_meta($post_id,'srp_tt_race_details',true);
  if (is_string($raw) && $raw !== '') {
    $j = json_decode($raw,true);
    if (is_array($j)) return $j;
  }
  if ($raceid) {
    if (function_exists('srp_tt_api_get_race')) {
      $j = srp_tt_api_get_race($raceid);
      if (is_array($j)) {
        update_post_meta($post_id,'srp_tt_race_details', wp_json_encode($j));
        if (!empty($j['startDateTime'])) update_post_meta($post_id,'srp_race_start', (string)$j['startDateTime']);
        if (!empty($j['name'])) update_post_meta($post_id,'srp_race_name', (string)$j['name']);
        return $j;
      }
    }
  }
  return null;
}
