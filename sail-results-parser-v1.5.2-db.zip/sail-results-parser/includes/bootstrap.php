<?php
/**
 * Bootstrap file for Sail Results Parser plugin
 */

if (!defined('ABSPATH')) exit;

// Load the main Plugin class
require_once __DIR__ . '/Plugin.php';

// Initialize the plugin
\SailResultsParser\Plugin::init();
