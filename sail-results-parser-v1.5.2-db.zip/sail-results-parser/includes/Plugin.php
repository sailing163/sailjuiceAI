<?php
namespace SailResultsParser;

if (!defined('ABSPATH')) exit;

class Plugin {
    public static function init() {
        add_action('init', [self::class, 'init_db_check']);
        add_action('admin_enqueue_scripts', [self::class, 'admin_enqueue_basics']);
        add_action('init', [self::class, 'register_post_type']);
        add_action('admin_menu', [self::class, 'register_admin_menus']);
        add_action('admin_init', [self::class, 'register_settings']);
        add_action('admin_enqueue_scripts', [self::class, 'admin_enqueue_modals']);
        add_action('wp_ajax_srp_save_row_edit', 'srp_ajax_save_row_edit');
        add_action('wp_ajax_srp_flickr_search', 'srp_ajax_flickr_search');
        add_shortcode('sail_results_import', [self::class, 'shortcode_sail_results_import']);
        add_action('admin_menu', [self::class, 'register_class_graph_menu']);
        add_action('admin_head', [self::class, 'admin_head_styles']);
        add_action('admin_post_srp_recalc_all', [self::class, 'handle_recalc_all']);
    }

    /**
     * Check and migrate database schema on init
     */
    public static function init_db_check() {
        $v = get_option('srp_db_version', '');
        if ($v !== SRP_DB_VERSION) srp_db_migrate();
    }

    /**
     * Enqueue leaflet and datatables for admin pages
     */
    public static function admin_enqueue_basics() {
        $page = isset($_GET['page']) ? sanitize_text_field(wp_unslash($_GET['page'])) : '';
        $post_type = isset($_GET['post_type']) ? sanitize_text_field(wp_unslash($_GET['post_type'])) : '';
        $pt = isset($_GET['post']) ? get_post_type((int)$_GET['post']) : '';

        if ($page === 'sail-results-parser' || $post_type === 'srp_import' || $pt === 'srp_import' || $page === 'srp-race-view') srp_enqueue_leaflet();
        if (in_array($page, ['srp-race-index','srp-class-stats','srp-race-view'], true)) srp_enqueue_datatables();
    }

    /**
     * Register srp_import custom post type
     */
    public static function register_post_type() {
        register_post_type('srp_import', [
            'labels' => ['name' => 'Sailing Imports','singular_name' => 'Sailing Import'],
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => 'sail-results-parser',
            'supports' => ['title'],
            'capability_type' => 'post',
            'map_meta_cap' => true,
        ]);
    }

    /**
     * Register main and submenu pages
     */
    public static function register_admin_menus() {
        add_menu_page('Sailing Results Import','Sailing Results','manage_options','sail-results-parser','srp_admin_page','dashicons-list-view',56);

        // Data QA (outliers)
        add_submenu_page(
            'sail-results-parser',
            'Data QA',
            'Data QA',
            'edit_posts',
            'srp-data-qa',
            'srp_data_qa_page'
        );

        add_submenu_page('sail-results-parser','Race Index','Race Index','manage_options','srp-race-index','srp_race_index_page');
        add_submenu_page('sail-results-parser','Class Stats','Class Stats','manage_options','srp-class-stats','srp_class_stats_page');
        add_submenu_page('sail-results-parser','RYA Bulk Import','RYA Bulk Import','manage_options','srp-rya-bulk-import','srp_rya_bulk_import_page');
        add_submenu_page(null,'Race View','Race View','manage_options','srp-race-view','srp_race_view_page');
        add_submenu_page('sail-results-parser','Sailing Imports','Sailing Imports','manage_options','edit.php?post_type=srp_import');
        add_submenu_page('sail-results-parser','Settings','Settings','manage_options','srp-settings','srp_settings_page');
        // make the hidden tools page accessible via the menu
        self::register_tools_menu();
    }

    /**
     * Register plugin settings
     */
    public static function register_settings() {
        register_setting('srp_settings', 'srp_tt_api_key', ['type' => 'string', 'sanitize_callback' => 'sanitize_text_field']);
        register_setting('srp_settings', 'srp_outlier_k', ['type' => 'number', 'sanitize_callback' => 'floatval', 'default' => 2.0]);
        register_setting('srp_settings', 'srp_enable_map', ['type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '1']);
        register_setting('srp_settings', 'srp_tt_viewer_url_tpl', ['type' => 'string', 'sanitize_callback' => 'sanitize_text_field']);
        register_setting('srp_settings', 'srp_flickr_api_key', ['type' => 'string', 'sanitize_callback' => 'sanitize_text_field']);
        register_setting('srp_settings', 'srp_flickr_user_id', ['type' => 'string', 'sanitize_callback' => 'sanitize_text_field']);
    }

    /**
     * Enqueue modal scripts and styles for admin pages
     */
    public static function admin_enqueue_modals($hook) {
        // Only load on our plugin pages
        $page = isset($_GET['page']) ? sanitize_key((string)$_GET['page']) : '';
        if(strpos($page, 'srp-') !== 0) return;

        wp_add_inline_style('wp-admin', '
            .srp-modal-backdrop{position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:100000;display:none;}
            .srp-modal{position:fixed;inset:5% 5%;background:#fff;z-index:100001;display:none;border-radius:6px;overflow:hidden;box-shadow:0 10px 40px rgba(0,0,0,.35);}
            .srp-modal header{display:flex;align-items:center;justify-content:space-between;padding:10px 12px;background:#f6f7f7;border-bottom:1px solid #dcdcde;}
            .srp-modal header h3{margin:0;font-size:14px;}
            .srp-modal .srp-modal-close{background:transparent;border:0;font-size:18px;line-height:1;cursor:pointer;}
            .srp-modal iframe{width:100%;height:100%;border:0;}
            .srp-modal .srp-modal-body{height:calc(100% - 44px);}
            .srp-modal-btn{margin-right:8px;}
            .srp-wind{display:inline-flex;align-items:center;gap:6px;white-space:nowrap;}
            .srp-wind-svg{display:block;}
            .srp-wind-label{font-size:12px;}
        ');

        wp_add_inline_script('jquery-core', '
            (function(){
                function ensureModal(){
                    if(document.getElementById("srpModal")) return;
                    var bd=document.createElement("div"); bd.id="srpModalBackdrop"; bd.className="srp-modal-backdrop";
                    var m=document.createElement("div"); m.id="srpModal"; m.className="srp-modal";
                    m.innerHTML = "<header><h3 id=\"srpModalTitle\">Viewer</h3><button type=\"button\" class=\"srp-modal-close\" aria-label=\"Close\">×</button></header><div class=\"srp-modal-body\"><div id=\"srpModalGallery\" style=\"display:none; padding:12px; overflow:auto; height:100%;\"></div><iframe id=\"srpModalFrame\" src=\"about:blank\" loading=\"lazy\"></iframe></div>";
                    document.body.appendChild(bd); document.body.appendChild(m);
                    function close(){ bd.style.display="none"; m.style.display="none"; document.getElementById("srpModalFrame").style.display="block"; document.getElementById("srpModalFrame").src="about:blank"; var g=document.getElementById("srpModalGallery"); if(g){ g.style.display="none"; g.innerHTML=""; } }
                    bd.addEventListener("click", close);
                    m.querySelector(".srp-modal-close").addEventListener("click", close);
                    window.srpOpenModal=function(url,title){
                        ensureModal(); bd.style.display="block"; m.style.display="block";
                        document.getElementById("srpModalTitle").textContent=title||"Viewer";
                        var frame=document.getElementById("srpModalFrame");
                        var gal=document.getElementById("srpModalGallery");
                        if(gal){ gal.style.display="none"; gal.innerHTML=""; }
                        frame.style.display="block";
                        frame.src=url;
                    };
                    window.srpOpenGallery=function(title, html){
                        ensureModal(); bd.style.display="block"; m.style.display="block";
                        document.getElementById("srpModalTitle").textContent=title||"Viewer";
                        var frame=document.getElementById("srpModalFrame");
                        var gal=document.getElementById("srpModalGallery");
                        frame.style.display="none"; frame.src="about:blank";
                        if(gal){ gal.style.display="block"; gal.innerHTML=html; }
                    };
                }
                ensureModal();
                document.addEventListener("click", function(e){
                    var a = e.target.closest("[data-srp-modal-url]");
                    if(!a) return;
                    e.preventDefault();
                    var url=a.getAttribute("data-srp-modal-url");
                    var title=a.getAttribute("data-srp-modal-title")||"Viewer";
                    // Mobile: hide TackTracker leaderboard if present
                    try {
                        if (window.innerWidth && window.innerWidth < 700 && url && url.indexOf("leaderboard=true") !== -1) {
                            url = url.replace("leaderboard=true", "leaderboard=false");
                        }
                    } catch(e) {}
                    if(window.srpOpenModal) window.srpOpenModal(url,title);
                });
                // Flickr API modal (admin AJAX)
                document.addEventListener("click", function(e){
                    var b = e.target.closest("[data-srp-flickr-raceid]");
                    if(!b) return;
                    e.preventDefault();
                    var raceid = b.getAttribute("data-srp-flickr-raceid");
                    var title = b.getAttribute("data-srp-modal-title") || ("Flickr: " + raceid);
                    if(!window.srpOpenGallery) return;
                    window.srpOpenGallery(title, "<p>Loading…</p>");
                    var fd = new FormData();
                    fd.append("action","srp_flickr_search");
                    fd.append("raceid", raceid);
                    if(postId) fd.append("post_id", postId);
                    if(raceStart) fd.append("race_start", raceStart);
                    fetch(ajaxurl, {method:"POST", credentials:"same-origin", body: fd})
                        .then(r=>r.json())
                        .then(function(data){
                            if(!data || !data.success){ throw new Error((data && data.data && data.data.message) ? data.data.message : "Search failed"); }
                            var photos = data.data.photos || [];
                            if(!photos.length){
                                window.srpOpenGallery(title, "<p>No Flickr photos found for <code>"+raceid+"</code>.</p>");
                                return;
                            }
                            var html = "<div style=\"display:flex;flex-wrap:wrap;gap:10px;\">";
                            photos.forEach(function(p){
                                html += "<a href=\""+p.page+"\" target=\"_blank\" style=\"text-decoration:none;\"><img src=\""+p.thumb+"\" alt=\"\" style=\"width:150px;height:150px;object-fit:cover;border:1px solid #ddd;border-radius:4px;\" /></a>";
                            });
                            html += "</div><p style=\"margin-top:10px;\"><em>Click a photo to open on Flickr.</em></p>";
                            window.srpOpenGallery(title, html);
                            // Bind thumbnail clicks to open full image in same modal
                            setTimeout(function(){
                                document.querySelectorAll(".srp-flickr-thumb").forEach(function(a){
                                    a.addEventListener("click", function(ev){
                                        ev.preventDefault();
                                        var full = a.getAttribute("data-full") || "";
                                        if(!full) return;
                                        window.srpOpenGallery(title, "<div style=\"text-align:center\"><img src=\""+full+"\" style=\"max-width:100%;height:auto\"></div>");
                                    });
                                });
                            }, 0);

                        })
                        .catch(function(err){
                            window.srpOpenGallery(title, "<p style=\"color:#b32d2e;\">"+(err && err.message ? err.message : "Error")+"</p>");
                        });
                });

            })();
        ');
    }

    /**
     * Shortcode: [sail_results_import]
     */
    public static function shortcode_sail_results_import($atts) {
        $atts = shortcode_atts(['cap' => 'manage_options','show_debug' => '0','show_map' => '1'], $atts, 'sail_results_import');
        $cap = (string)$atts['cap'];
        $show_debug = ($atts['show_debug'] === '1' || strtolower((string)$atts['show_debug']) === 'true');
        $show_map = !($atts['show_map'] === '0' || strtolower((string)$atts['show_map']) === 'false');

        if (!is_user_logged_in()) return '<p><em>You must be logged in to import results.</em></p>';
        if ($cap && !current_user_can($cap)) return '<p><em>You do not have permission to import results.</em></p>';

        if (function_exists('wp_enqueue_editor')) wp_enqueue_editor();
        if ($show_map) add_action('wp_enqueue_scripts','srp_enqueue_leaflet');

        ob_start();
        srp_render_import_ui(['context'=>'shortcode','show_debug'=>$show_debug,'show_map'=>$show_map]);
        return ob_get_clean();
    }

    /**
     * Register class graph submenu (hidden)
     */
    public static function register_class_graph_menu() {
        add_submenu_page(null, 'Class Graph', 'Class Graph', 'manage_options', 'srp-class-graph', 'srp_class_graph_page');
        add_submenu_page(null, 'Class Races', 'Class Races', 'manage_options', 'srp-class-races', 'srp_class_races_page');
    }

    /**
     * Register tools page (hidden until plugin version bump)
     */
    public static function register_tools_menu() {
        // add it under our top-level "Sailing Results" menu so administrators can find it
        add_submenu_page(
            'sail-results-parser', // parent slug (matches add_menu_page above)
            'SRP Tools',           // page title
            'Tools',               // menu title
            'manage_options',      // capability
            'srp-tools',           // menu slug
            'srp_tools_page'       // callback
        );
    }

    /**
     * Add inline styles to admin head for plugin pages
     */
    public static function admin_head_styles() {
        if (!isset($_GET['page'])) return;
        if (strpos($_GET['page'], 'srp-') !== 0 && $_GET['page'] !== 'srp_race') return;
        echo '<style>
            tr.srp-excluded-row { opacity: 0.45; }
            tr.srp-excluded-row td { background: #f3f3f3 !important; }
            .srp-threshold-box{margin:10px 0 16px 0;padding:10px 12px;background:#fff;border:1px solid #dcdcde;border-left:4px solid #2271b1;}
            .srp-threshold-box code{font-size:12px;}
        </style>';
    }

    /**
     * Handle recalculation of all races (dual analysis)
     */
    public static function handle_recalc_all() {
        if (!current_user_can('manage_options')) wp_die('Not allowed');
        if (!isset($_POST['srp_nonce']) || !wp_verify_nonce($_POST['srp_nonce'], 'srp_recalc_all')) wp_die('Bad nonce');

        $posts = get_posts([
            'post_type' => 'srp_import',
            'post_status' => 'any',
            'numberposts' => -1,
            'fields' => 'ids',
        ]);
        if (is_array($posts)){
            foreach ($posts as $post_id){
                if (function_exists('srp_recalculate_post_stats')) srp_recalculate_post_stats($post_id);
            }
        }
        if (function_exists('srp_db_rebuild_class_summary')) srp_db_rebuild_class_summary();
        wp_safe_redirect(add_query_arg(['page'=>'srp-tools','srp_done'=>1], admin_url('admin.php')));
        exit;
    }
}
