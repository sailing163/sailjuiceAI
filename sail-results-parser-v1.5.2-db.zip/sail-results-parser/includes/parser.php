<?php
if (!defined('ABSPATH')) exit;

/**
 * Parse pasted HTML results and return rows suitable for a preview table.
 *
 * @param string $html
 * @return array{rows: array<int, array<string,string>>, debug: array<string,mixed>, error?: string}
 */
function srp_parse_results_html($html) {
  $out = [
    'rows' => [],
    'debug' => [
      'tables_found' => 0,
      'chosen_table_index' => null,
      'chosen_table_score' => null,
      'header_row_index' => null,
      'raw_matrix' => [],
    ],
  ];

  // Wrap fragments so DOMDocument can load them.
  $wrapped = $html;
  if (stripos($html, '<html') === false) {
    $wrapped = '<!doctype html><html><head><meta charset="utf-8"></head><body>' . $html . '</body></html>';
  }

  libxml_use_internal_errors(true);
  $dom = new DOMDocument();
  $loaded = $dom->loadHTML($wrapped, LIBXML_NOWARNING | LIBXML_NOERROR);
  libxml_clear_errors();

  if (!$loaded) {
    $out['error'] = 'Could not parse HTML.';
    return $out;
  }

  $xpath = new DOMXPath($dom);
  $tables = $xpath->query('//table');
  $out['debug']['tables_found'] = $tables ? $tables->length : 0;

  if (!$tables || $tables->length === 0) {
    $out['error'] = 'No <table> elements found in the pasted HTML.';
    return $out;
  }

  // Score tables and choose best candidate.
  $bestIdx = null;
  $bestScore = -1;
  $bestMatrix = [];

  for ($i = 0; $i < $tables->length; $i++) {
    $t = $tables->item($i);
    $matrix = srp_table_to_matrix($t);
    $rowCount = count($matrix);
    $colCount = 0;
    foreach ($matrix as $r) $colCount = max($colCount, count($r));

    if ($rowCount < 2 || $colCount < 4) continue;

    // Score: area + bonus for header keywords present in first few rows.
    $area = $rowCount * $colCount;
    $bonus = 0;
    $sampleRows = array_slice($matrix, 0, min(5, $rowCount));
    $sampleText = strtolower(implode(' ', array_map(function($r){ return implode(' ', $r); }, $sampleRows)));
    $keywords = ['helm','helm name','skipper','sail','sail no','sailno','class','club','rank','place','py','rating','yardstick','corrected','corr','achieved','total','points','nett','time','elapsed'];
    foreach ($keywords as $k) {
      if (strpos($sampleText, $k) !== false) $bonus += 50;
    }

    $score = $area + $bonus;

    if ($score > $bestScore) {
      $bestScore = $score;
      $bestIdx = $i;
      $bestMatrix = $matrix;
    }
  }

  // If nothing met thresholds, fallback to the largest by area anyway.
  if ($bestIdx === null) {
    for ($i = 0; $i < $tables->length; $i++) {
      $matrix = srp_table_to_matrix($tables->item($i));
      $rowCount = count($matrix);
      $colCount = 0;
      foreach ($matrix as $r) $colCount = max($colCount, count($r));
      $score = $rowCount * $colCount;
      if ($score > $bestScore) {
        $bestScore = $score;
        $bestIdx = $i;
        $bestMatrix = $matrix;
      }
    }
  }

  $out['debug']['chosen_table_index'] = $bestIdx;
  $out['debug']['chosen_table_score'] = $bestScore;
  $out['debug']['raw_matrix'] = $bestMatrix;

  // Detect header row
  $headerIdx = srp_detect_header_row($bestMatrix);
  $out['debug']['header_row_index'] = $headerIdx;

  // Build headers
  $headers = [];
  if ($headerIdx !== null && isset($bestMatrix[$headerIdx])) {
    $headers = srp_normalize_headers($bestMatrix[$headerIdx]);
  } else {
    // Create generic headers
    $maxCols = 0;
    foreach ($bestMatrix as $r) $maxCols = max($maxCols, count($r));
    for ($c=0; $c<$maxCols; $c++) $headers[] = 'Col ' . ($c+1);
    $headerIdx = -1;
  }

  // Convert following rows into associative arrays
  $rows = [];
  for ($r = $headerIdx + 1; $r < count($bestMatrix); $r++) {
    $cells = $bestMatrix[$r];
    // Skip empty rows
    $nonEmpty = false;
    foreach ($cells as $v) { if (trim($v) !== '') { $nonEmpty = true; break; } }
    if (!$nonEmpty) continue;

    $assoc = [];
    for ($c = 0; $c < count($headers); $c++) {
      $val = isset($cells[$c]) ? $cells[$c] : '';
      $assoc[$headers[$c]] = srp_clean_cell($val);
    }

    // Remove rows that look like repeated headers or separators
    if (srp_row_looks_like_header_repeat($assoc, $headers)) continue;

    $rows[] = $assoc;
    if (count($rows) >= 500) break; // safety limit
  }

  // If headers have "Time" columns, normalize time formats in those cells
  if (!empty($rows)) {
    $timeCols = [];
    foreach ($headers as $h) {
      if (preg_match('/\btime\b|\belapsed\b|\bcorrected\b|\bcorr\b/i', $h)) $timeCols[] = $h;
    }
    if (!empty($timeCols)) {
      foreach ($rows as &$row) {
        foreach ($timeCols as $tc) {
          if (!empty($row[$tc])) {
            $row[$tc] = srp_normalize_time_string($row[$tc]);
          }
        }
      }
      unset($row);
    }
  }

  $out['rows'] = srp_canonicalize_html_rows($rows);
  return $out;
}

/**
 * Convert a DOM <table> to a 2D matrix of cell text.
 */
function srp_table_to_matrix(DOMNode $table) {
  $rows = [];
  $xpath = new DOMXPath($table->ownerDocument);
  $trNodes = $xpath->query('.//tr', $table);
  if (!$trNodes) return $rows;

  foreach ($trNodes as $tr) {
    $cellNodes = $xpath->query('./th|./td', $tr);
    if (!$cellNodes) continue;

    $row = [];
    foreach ($cellNodes as $cell) {
      $txt = srp_node_text($cell);
      $row[] = $txt;
    }
    // Trim trailing empties
    while (count($row) > 0 && trim($row[count($row)-1]) === '') array_pop($row);
    $rows[] = $row;
  }

  return $rows;
}

function srp_node_text(DOMNode $node) {
  // Convert <br> to spaces/newlines by cloning HTML and stripping tags
  $html = $node->ownerDocument->saveHTML($node);
  $html = preg_replace('/<br\s*\/?>/i', "\n", $html);
  $text = wp_strip_all_tags($html);
  $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
  // Collapse whitespace but keep newlines into spaces
  $text = preg_replace("/[ \t\r\f\v]+/u", " ", $text);
  $text = preg_replace("/\n+/u", " ", $text);
  return trim($text);
}

function srp_detect_header_row(array $matrix) {
  $keywords = ['helm','helm name','skipper','sail','sail no','sailno','class','club','rank','place','py','rating','yardstick','corrected','corr','achieved','total','points','nett','time','elapsed'];
  $maxCheck = min(8, count($matrix));
  $bestIdx = null;
  $bestScore = -1;

  for ($i=0; $i<$maxCheck; $i++) {
    $row = $matrix[$i];
    if (count($row) < 2) continue;
    $text = strtolower(implode(' ', $row));

    $score = 0;
    foreach ($keywords as $k) {
      if (strpos($text, $k) !== false) $score += 8;
    }
    if (strpos($text, 'elapsed') !== false && (strpos($text, 'corrected') !== false || strpos($text, 'corr') !== false)) $score += 15;
    if (strpos($text, 'py') !== false && strpos($text, 'rank') !== false) $score += 10;
    // Penalize numeric-heavy rows (likely data)
    $numericCells = 0;
    foreach ($row as $cell) {
      $cellTrim = trim($cell);
      if ($cellTrim !== '' && preg_match('/^[\d\W]+$/u', $cellTrim)) $numericCells++;
    }
    $score -= $numericCells;

    // Prefer rows with more distinct non-empty strings
    $nonEmpty = array_filter($row, function($v){ return trim($v) !== ''; });
    $score += min(5, count($nonEmpty));

    if ($score > $bestScore) {
      $bestScore = $score;
      $bestIdx = $i;
    }
  }

  if ($bestIdx !== null && $bestScore >= 4) return $bestIdx;

  return null;
}


function srp_html_value_looks_like_time($v) {
  $v = trim((string)$v);
  if ($v === '') return false;
  return (bool) preg_match('/^\d{1,2}[\.:]\d{2}(?:[\.:]\d{2})?$/', $v);
}

function srp_html_value_looks_like_py($v) {
  $v = trim((string)$v);
  if ($v === '' || !is_numeric($v)) return false;
  $n = floatval($v);
  return ($n >= 500 && $n <= 1800);
}


function srp_html_class_looks_like_fleet($v) {
  $v = strtolower(trim((string)$v));
  if ($v === '') return false;
  $fleet_words = ['fast','slow','medium','gold','silver','bronze','alpha','beta','gamma','handicap','asymmetric','symmetric','fleet a','fleet b','fleet c'];
  return in_array($v, $fleet_words, true);
}

function srp_canonicalize_html_rows(array $rows) {
  foreach ($rows as &$row) {
    if (!is_array($row)) continue;

    // map common aliases to canonical keys
    foreach (['Name','Helm','Skipper'] as $k) {
      if (!empty($row[$k]) && empty($row['Helm Name'])) $row['Helm Name'] = $row[$k];
    }
    foreach (['Crew','Crew name'] as $k) {
      if (!empty($row[$k]) && empty($row['Crew Name'])) $row['Crew Name'] = $row[$k];
    }
    foreach (['Rating','Yardstick','PN'] as $k) {
      if (!empty($row[$k]) && empty($row['PY'])) $row['PY'] = $row[$k];
    }
    foreach (['Sail No','Sail Number','Sail #','Sail ID','Bib'] as $k) {
      if (!empty($row[$k]) && empty($row['Sail No'])) $row['Sail No'] = $row[$k];
    }
    foreach (['Corrected','Corrected time','Corrected Time','Corr'] as $k) {
      if (!empty($row[$k]) && empty($row['Corr.'])) $row['Corr.'] = $row[$k];
    }
    foreach (['Achieved','Achieved PY','Result PY','New PY'] as $k) {
      if (!empty($row[$k]) && empty($row['Source Achieved PY'])) $row['Source Achieved PY'] = $row[$k];
    }

    // If pasted HTML uses a fleet column like Fast/Slow in "Class", prefer actual boat type/design as Class.
    $boat_like = '';
    foreach (['Boat','Boat Name','Boat Type','Design','Class Name','Boat Class','boatname'] as $k) {
      if (!empty($row[$k])) { $boat_like = $row[$k]; break; }
    }
    if ($boat_like !== '' && (!empty($row['Class']) && srp_html_class_looks_like_fleet($row['Class']))) {
      $row['Fleet'] = $row['Class'];
      $row['Class'] = $boat_like;
    } elseif ($boat_like !== '' && empty($row['Class'])) {
      $row['Class'] = $boat_like;
    }

    // Exclusion/status handling for pasted HTML result tables
    $status_text = '';
    foreach (['Result Code','Status','Code','Result','Elapsed','Corr.','Source Achieved PY'] as $k) {
      if (!empty($row[$k])) $status_text .= ' ' . strtoupper(trim((string)$row[$k]));
    }
    if (preg_match('/\b(OCS|DNS|DNF|DSQ|DNC|RET|BFD|UFD|NSC|RAF|RDG|SCP)\b/', $status_text, $m)) {
      $row['Excluded manual'] = 'Yes';
      $row['Manual Exclusion Reason'] = $m[1];
      if (empty($row['Elapsed']) || !srp_html_value_looks_like_time($row['Elapsed'])) $row['Elapsed'] = '';
      if (empty($row['Corr.']) || !srp_html_value_looks_like_time($row['Corr.'])) $row['Corr.'] = '';
      if (empty($row['Source Achieved PY']) || !is_numeric($row['Source Achieved PY'])) $row['Source Achieved PY'] = '';
    }

    // Heuristic repair for HTML tables where time/numeric columns are shifted
    $time_vals = [];
    $py_like_vals = [];
    foreach ($row as $key => $val) {
      $sv = trim((string)$val);
      if ($sv === '') continue;
      if (srp_html_value_looks_like_time($sv)) $time_vals[] = $sv;
      if (srp_html_value_looks_like_py($sv)) $py_like_vals[] = $sv;
    }

    if ((empty($row['Elapsed']) || !srp_html_value_looks_like_time($row['Elapsed'])) && count($time_vals) >= 1) {
      $row['Elapsed'] = $time_vals[0];
    }
    if ((empty($row['Corr.']) || !srp_html_value_looks_like_time($row['Corr.'])) && count($time_vals) >= 2) {
      $row['Corr.'] = $time_vals[1];
    }
    if (empty($row['Sail No'])) {
      foreach ($row as $key => $val) {
        $sv = trim((string)$val);
        if ($sv === '') continue;
        if (preg_match('/^[A-Za-z]*\d{2,}[A-Za-z]*$/', $sv)) {
          if (!srp_html_value_looks_like_time($sv)) {
            $num = preg_replace('/\D+/', '', $sv);
            $py_current = isset($row['PY']) && is_numeric($row['PY']) ? floatval($row['PY']) : null;
            $laps_current = isset($row['Laps']) && is_numeric($row['Laps']) ? floatval($row['Laps']) : null;
            if (($py_current === null || abs(floatval($num) - $py_current) > 0.01) && ($laps_current === null || abs(floatval($num) - $laps_current) > 0.01)) {
              $row['Sail No'] = $sv;
              break;
            }
          }
        }
      }
    }

    if (empty($row['Source Achieved PY']) && count($py_like_vals) >= 2) {
      $py_current = isset($row['PY']) && is_numeric($row['PY']) ? floatval($row['PY']) : null;
      foreach ($py_like_vals as $cand) {
        if ($py_current === null || abs(floatval($cand) - $py_current) > 0.01) {
          $row['Source Achieved PY'] = $cand;
          break;
        }
      }
    }
  }

  // Final exclusion pass: rows without usable elapsed/corrected/source-achieved data
  // are almost always OCS/DNS/DNF style rows in pasted HTML results and should not
  // be included in calculations.
  foreach ($rows as &$row) {
    if (!is_array($row)) continue;

    $elapsed_ok = !empty($row['Elapsed']) && srp_html_value_looks_like_time($row['Elapsed']);
    $corr_ok = !empty($row['Corr.']) && srp_html_value_looks_like_time($row['Corr.']);
    $source_ok = !empty($row['Source Achieved PY']) && is_numeric($row['Source Achieved PY']);

    if (!$elapsed_ok && !$corr_ok && !$source_ok) {
      $row['Excluded manual'] = 'Yes';
      if (empty($row['Manual Exclusion Reason'])) $row['Manual Exclusion Reason'] = 'No elapsed/corr';
      $row['Excluded (All)'] = 'Yes';
      $row['Excluded (Best)'] = 'Yes';
      $row['Excluded (RYA)'] = 'Yes';
    }
  }
  unset($row);
  unset($row);
  return $rows;
}

function srp_normalize_headers(array $headerRow) {
  $headers = [];
  $seen = [];
  foreach ($headerRow as $i => $h) {
    $h = srp_clean_cell($h);
    if ($h === '') $h = 'Col ' . ($i+1);

    // Normalize a few common variants
    $map = [
      'sailno' => 'Sail No',
      'sail no' => 'Sail No',
      'sail number' => 'Sail No',
      'sail #' => 'Sail No',
      'sail no.' => 'Sail No',
      'sailnum' => 'Sail No',
      'sail id' => 'Sail No',
      'bib' => 'Sail No',
      'helm' => 'Helm Name',
      'helm name' => 'Helm Name',
      'skipper' => 'Helm Name',
      'name' => 'Helm Name',
      'crew' => 'Crew Name',
      'crew name' => 'Crew Name',
      'class' => 'Class',
      'boat' => 'Boat',
      'boat name' => 'Boat',
      'boat type' => 'Boat',
      'design' => 'Boat',
      'fleet' => 'Fleet',
      'result' => 'Result Code',
      'status' => 'Result Code',
      'code' => 'Result Code',
      'club' => 'Club',
      'rank' => 'Rank',
      'place' => 'Rank',
      'py' => 'PY',
      'rating' => 'PY',
      'yardstick' => 'PY',
      'laps' => 'Laps',
      'lap' => 'Laps',
      'corrected' => 'Corr.',
      'corrected per lap' => 'Corr.',
      'corrected/lap' => 'Corr.',
      'corrected time' => 'Corr.',
      'corr' => 'Corr.',
      'achieved' => 'Source Achieved PY',
      'achieved py' => 'Source Achieved PY',
      'total' => 'Total',
      'points' => 'Points',
      'nett' => 'Nett',
      'time' => 'Elapsed',
      'elapsed/corrected' => 'Elapsed',
      'elapsed' => 'Elapsed',
      'elapsed time' => 'Elapsed',
    ];
    $key = strtolower(trim($h));
    if (isset($map[$key])) $h = $map[$key];

    // De-dupe
    $base = $h;
    $n = 2;
    while (isset($seen[strtolower($h)])) {
      $h = $base . ' ' . $n;
      $n++;
    }
    $seen[strtolower($h)] = true;
    $headers[] = $h;
  }
  return $headers;
}

function srp_clean_cell($v) {
  $v = trim((string)$v);
  $v = preg_replace("/\s+/u", " ", $v);
  return $v;
}

function srp_row_looks_like_header_repeat(array $assoc, array $headers) {
  $joined = strtolower(implode(' ', array_values($assoc)));
  $hits = 0;
  foreach ($headers as $h) {
    $hh = strtolower(preg_replace('/\s+/', ' ', trim($h)));
    if ($hh !== '' && strpos($joined, $hh) !== false) $hits++;
  }
  return $hits >= max(3, (int)floor(count($headers) / 2));
}

/**
 * Normalize time-like strings to H:MM:SS when possible.
 */
function srp_normalize_time_string($s) {
  $s = trim((string)$s);
  if ($s === '') return $s;

  // Extract first time-ish token if mixed content
  if (preg_match('/(\d{1,3}:\d{2}:\d{2}|\d{1,3}:\d{2})(?!\d)/', $s, $m)) {
    $s = $m[1];
  }

  $parts = explode(':', $s);
  if (count($parts) < 2 || count($parts) > 3) return $s;

  $nums = array_map('intval', $parts);
  if (count($nums) === 2) {
    // MM:SS -> convert to H:MM:SS
    $mm = $nums[0]; $ss = $nums[1];
    if ($ss >= 60) return $s;
    $hh = intdiv($mm, 60);
    $mm2 = $mm % 60;
    return sprintf('%d:%02d:%02d', $hh, $mm2, $ss);
  } else {
    $hh = $nums[0]; $mm = $nums[1]; $ss = $nums[2];
    if ($mm >= 60 || $ss >= 60) return $s;
    return sprintf('%d:%02d:%02d', $hh, $mm, $ss);
  }
}
