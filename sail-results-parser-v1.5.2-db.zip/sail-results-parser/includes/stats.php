<?php
if (!defined('ABSPATH')) exit;

function srp_time_to_seconds($t) {
    if ($t === null) return null;
    $t = trim((string)$t);
    if ($t === '') return null;

    if (strpos($t, ':') === false && preg_match('/^\d+(\.\d+)+$/', $t)) {
        $t = implode(':', explode('.', $t));
    }

    if (preg_match('/^\d+:\d+(:\d+(\.\d+)?)?$/', $t)) {
        $parts = explode(':', $t);
        if (count($parts) === 2) return intval($parts[0]) * 60 + floatval($parts[1]);
        if (count($parts) === 3) return intval($parts[0]) * 3600 + intval($parts[1]) * 60 + floatval($parts[2]);
    }

    if (preg_match('/^\d+(\.\d+)?$/', $t)) return floatval($t);
    return null;
}

function srp_mean($a){
    $a = array_values(array_filter($a, fn($v) => is_numeric($v)));
    if(!$a) return null;
    return array_sum($a)/count($a);
}

function srp_median($a){
    $a = array_values(array_filter($a, fn($v) => is_numeric($v)));
    if(!$a) return null;
    sort($a, SORT_NUMERIC);
    $n=count($a);
    $mid=intdiv($n,2);
    return ($n%2)?$a[$mid]:(($a[$mid-1]+$a[$mid])/2);
}

function srp_stddev_sample($a){
    $a = array_values(array_filter($a, fn($v) => is_numeric($v)));
    if(count($a)<2) return 0.0;
    $mean=srp_mean($a);
    $sum=0.0;
    foreach($a as $v){
        $sum += ($v-$mean)*($v-$mean);
    }
    return sqrt($sum/(count($a)-1));
}

function srp_detect_result_columns(array $rows) {
    $out = ['class'=>null,'elapsed'=>null,'laps'=>null,'py'=>null,'sail'=>null,'rank'=>null];
    $headers = [];
    foreach ($rows as $r) {
        if (is_array($r)) $headers = array_merge($headers, array_keys($r));
    }
    $headers = array_values(array_unique($headers));
    foreach ($headers as $h) {
        if ($out['class']===null && preg_match('/\bclass\b|boat\s*class|fleet|division/i', $h)) $out['class']=$h;
        if ($out['elapsed']===null && preg_match('/elapsed_time|\belapsed\b|\btime\b/i', $h)) $out['elapsed']=$h;
        if ($out['laps']===null && preg_match('/\blaps?\b/i', $h)) $out['laps']=$h;
        if ($out['py']===null && preg_match('/\bpy\b|\bgl\b|handicap|rating/i', $h)) $out['py']=$h;
        if ($out['sail']===null && preg_match('/sail_number|sail\s*no|sailno|sail number|sailnumber/i', $h)) $out['sail']=$h;
        if ($out['rank']===null && preg_match('/\brank\b|\bplace\b|\bposition\b|\bpos\b/i', $h)) $out['rank']=$h;
    }
    return $out;
}

function srp_normalize_result_rows(array $rows) {
    $cols = srp_detect_result_columns($rows);
    $items = [];
    foreach($rows as $idx=>$r){
        if (!is_array($r)) continue;
        $manual_ex = trim((string)($r['Excluded manual'] ?? $r['Manual Excluded'] ?? ''));
        $elapsed = srp_time_to_seconds($r[$cols['elapsed']] ?? '');
        $laps_raw = $cols['laps'] ? ($r[$cols['laps']] ?? '1') : '1';
        $laps = intval(preg_replace('/\D+/', '', (string)$laps_raw));
        if ($laps <= 0) $laps = 1;
        $py_raw = $cols['py'] ? ($r[$cols['py']] ?? '') : '';
        $py = floatval(preg_replace('/[^0-9.]/', '', (string)$py_raw));
        $class = trim((string)($cols['class'] ? ($r[$cols['class']] ?? '') : ''));
        $rank_raw = $cols['rank'] ? ($r[$cols['rank']] ?? '') : '';
        $rank = intval(preg_replace('/\D+/', '', (string)$rank_raw));
        if ($rank <= 0) $rank = $idx + 1;
        $sail = trim((string)($cols['sail'] ? ($r[$cols['sail']] ?? '') : ''));
        if (!$elapsed || !$py || $class === '') continue;

        $corr = (1000.0 / $py) * ($elapsed / $laps);
        $boat_id = $sail !== '' ? $sail : ('row'.$idx);

        $items[] = [
            'idx'=>$idx,
            'class'=>$class,
            'boat_id'=>$boat_id,
            'elapsed'=>$elapsed,
            'laps'=>$laps,
            'py'=>$py,
            'corr'=>$corr,
            'rank'=>$rank,
            'manual_excluded'=>in_array(strtolower($manual_ex), ['yes','1','true'], true),
        ];
    }
    return [$items, $cols];
}

function srp_apply_display_fields(array $rows, array $items){
    foreach($items as $it){
        $rows[$it['idx']]['Corr.'] = (int) round($it['corr']);
    }
    return $rows;
}

function srp_compute_allboats(array $rows, $k=2.0){
    [$items, $cols] = srp_normalize_result_rows($rows);
    $debug = ['method'=>'allboats','k'=>$k];
    if (empty($items)) return ['rows'=>$rows,'class_stats'=>[],'debug'=>$debug];

    $updated = srp_apply_display_fields($rows, $items);

    $boat_corrs = [];
    foreach($items as $it){
        if ($it['manual_excluded']) continue;
        $boat_corrs[$it['boat_id']][] = $it['corr'];
    }
    $boat_avgs = [];
    foreach($boat_corrs as $bid=>$vals) $boat_avgs[$bid] = srp_mean($vals);

    $vals = array_values($boat_avgs);
    $mean = srp_mean($vals);
    $sd = srp_stddev_sample($vals);
    $low = ($sd > 0) ? $mean - ($k * $sd) : null;
    $high = ($sd > 0) ? $mean + ($k * $sd) : null;

    $excluded_boats = [];
    foreach($boat_avgs as $bid=>$avg){
        // Exclude only poor performers (high/slow outliers), not top performers.
        if ($high !== null && $avg > $high) $excluded_boats[$bid] = 'Poor performer outlier';
    }

    $included = [];
    foreach($boat_avgs as $bid=>$avg){
        if (!isset($excluded_boats[$bid])) $included[] = $avg;
    }
    $sct = srp_median($included);

    $debug['mean']=$mean;
    $debug['sd']=$sd;
    $debug['low']=$low;
    $debug['high']=$high;
    $debug['sct']=$sct;
    $debug['boats_n']=count($boat_avgs);
    $debug['boats_excluded']=count($excluded_boats);

    $class_vals = [];
    foreach($items as $it){
        $idx = $it['idx'];
        $excluded = $it['manual_excluded'] || isset($excluded_boats[$it['boat_id']]) || !$sct;
        $updated[$idx]['Excluded (All)'] = $excluded ? 'Yes' : 'No';
        if ($it['manual_excluded']) $updated[$idx]['Exclusion Reason (All)'] = 'Manual exclusion';
        elseif (isset($excluded_boats[$it['boat_id']])) $updated[$idx]['Exclusion Reason (All)'] = 'Outlier';

        $derived = (!$excluded && $sct > 0) ? (($it['corr'] / $sct) * $it['py']) : null;
        $updated[$idx]['Derived PY/GL (All)'] = $derived !== null ? (int) round($derived) : '';
        if (!$excluded && $derived !== null) $class_vals[$it['class']][] = $derived;
    }

    $class_stats = [];
    foreach($class_vals as $class=>$vals2){
        $class_stats[$class] = [
            'class'=>$class,
            'derived_py'=>srp_median($vals2),
            'n'=>count($vals2),
            'sct'=>$sct,
            'low'=>$low,
            'high'=>$high,
            'mean'=>$mean,
            'stddev'=>$sd,
            'k'=>$k,
        ];
    }

    return ['rows'=>$updated,'class_stats'=>$class_stats,'debug'=>$debug];
}

function srp_compute_bestofclass_sd(array $rows, $k=2.0){
    [$items, $cols] = srp_normalize_result_rows($rows);
    $debug = ['method'=>'bestofclass'];
    if (empty($items)) return ['rows'=>$rows,'class_stats'=>[],'debug'=>$debug];

    $updated = srp_apply_display_fields($rows, $items);

    $best_by_class = [];
    foreach($items as $it){
        if ($it['manual_excluded']) continue;
        if (!isset($best_by_class[$it['class']]) || $it['corr'] < $best_by_class[$it['class']]['corr']) {
            $best_by_class[$it['class']] = $it;
        }
    }

    $best_corrs = array_map(fn($x) => $x['corr'], $best_by_class);
    $sct = srp_median(array_values($best_corrs));
    $debug['sct'] = $sct;
    $debug['classes_n'] = count($best_by_class);

    $class_stats = [];
    foreach($best_by_class as $class=>$best){
        $derived = ($sct > 0) ? (($best['corr'] / $sct) * $best['py']) : null;
        $class_stats[$class] = [
            'class'=>$class,
            'derived_py'=>$derived,
            'n'=>1,
            'sct'=>$sct,
            'best_corrected_lap_s'=>$best['corr'],
            'best_boat_id'=>$best['boat_id'],
        ];
    }

    foreach($items as $it){
        $idx = $it['idx'];
        $updated[$idx]['Excluded (Best)'] = $it['manual_excluded'] ? 'Yes' : 'No';
        if ($it['manual_excluded']) $updated[$idx]['Exclusion Reason (Best)'] = 'Manual exclusion';
        $updated[$idx]['Derived PY/GL (Best)'] = isset($class_stats[$it['class']]['derived_py']) ? (int) round($class_stats[$it['class']]['derived_py']) : '';
    }

    return ['rows'=>$updated,'class_stats'=>$class_stats,'debug'=>$debug];
}

function srp_compute_bestofclass(array $rows){
    return srp_compute_bestofclass_sd($rows, 2.0);
}

function srp_compute_rya_median_v2(array $rows){
    [$items, $cols] = srp_normalize_result_rows($rows);
    $debug = ['method'=>'rya66'];
    if (empty($items)) return ['rows'=>$rows,'class_stats'=>[],'debug'=>$debug];

    $updated = srp_apply_display_fields($rows, $items);

    $boats = [];
    foreach($items as $it){
        if ($it['manual_excluded']) continue;
        if (!isset($boats[$it['boat_id']])) {
            $boats[$it['boat_id']] = ['class'=>$it['class'],'py'=>$it['py'],'rank'=>$it['rank'],'corrs'=>[]];
        }
        $boats[$it['boat_id']]['corrs'][] = $it['corr'];
        $boats[$it['boat_id']]['rank'] = min($boats[$it['boat_id']]['rank'], $it['rank']);
    }

    foreach($boats as $bid=>$b){
        $boats[$bid]['corr_avg'] = srp_mean($b['corrs']);
    }

    uasort($boats, function($a,$b){
        if ($a['rank'] === $b['rank']) return $a['corr_avg'] <=> $b['corr_avg'];
        return $a['rank'] <=> $b['rank'];
    });

    $top_n = max(1, (int) ceil(count($boats) * 0.66));
    $top = array_slice($boats, 0, $top_n, true);
    $top_corrs = array_map(fn($b) => $b['corr_avg'], $top);
    $median_top = srp_median($top_corrs);
    $threshold = $median_top !== null ? $median_top * 1.10 : null;

    $included_boats = [];
    $excluded_boats = [];
    foreach($boats as $bid=>$b){
        if ($threshold !== null && $b['corr_avg'] <= $threshold) $included_boats[$bid] = true;
        else $excluded_boats[$bid] = '>110% median';
    }

    $included_corrs = [];
    foreach($boats as $bid=>$b){
        if (isset($included_boats[$bid])) $included_corrs[] = $b['corr_avg'];
    }
    $sct = srp_median($included_corrs);

    $debug['top_n']=$top_n;
    $debug['median_top66']=$median_top;
    $debug['threshold']=$threshold;
    $debug['sct']=$sct;
    $debug['boats_n']=count($boats);
    $debug['boats_included']=count($included_boats);
    $debug['boats_excluded']=count($excluded_boats);

    $class_vals = [];
    foreach($items as $it){
        $idx = $it['idx'];
        $excluded = $it['manual_excluded'] || isset($excluded_boats[$it['boat_id']]) || !$sct;
        $updated[$idx]['Excluded (RYA)'] = $excluded ? 'Yes' : 'No';
        if ($it['manual_excluded']) $updated[$idx]['Exclusion Reason (RYA)'] = 'Manual exclusion';
        elseif (isset($excluded_boats[$it['boat_id']])) $updated[$idx]['Exclusion Reason (RYA)'] = '>110% median';

        $derived = (!$excluded && $sct > 0) ? (($it['corr'] / $sct) * $it['py']) : null;
        $updated[$idx]['Derived PY/GL (RYA)'] = $derived !== null ? (int) round($derived) : '';
        if (!$excluded && $derived !== null) $class_vals[$it['class']][] = $derived;
    }

    $class_stats = [];
    foreach($class_vals as $class=>$vals2){
        $class_stats[$class] = [
            'class'=>$class,
            'derived_py'=>srp_median($vals2),
            'n'=>count($vals2),
            'sct'=>$sct,
            'median_top66'=>$median_top,
            'threshold'=>$threshold,
        ];
    }

    return ['rows'=>$updated,'class_stats'=>$class_stats,'debug'=>$debug];
}

function srp_compute_rya_median(array $rows){
    return srp_compute_rya_median_v2($rows);
}

function srp_compute_dual(array $rows, $k=2.0){
    return [
        'all'  => srp_compute_allboats($rows, $k),
        'best' => srp_compute_bestofclass_sd($rows, $k),
        'rya'  => srp_compute_rya_median_v2($rows),
    ];
}

function srp_compute_dual_v2(array $rows, $k=2.0){
    return srp_compute_dual($rows, $k);
}

function srp_compute_dual_analysis(array $rows, $k=2.0){
    return srp_compute_dual($rows, $k);
}
