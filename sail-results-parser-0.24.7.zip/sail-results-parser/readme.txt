Sail Results Parser v0.21.0
- Add: Tools page with global 'Recalculate all races'
- Add: Weather fields on race view (Wind/Direction/Temperature/Pressure)
- Fix: map rotation improved (pane selector + timing)
- IMPORTANT: To update version in WP, delete old plugin folder and upload this zip.
